import type { Achievement, Career } from "./types"

export type Rank = {
  id: string
  title: string
  minXp: number
  blurb: string
}

export const RANKS: Rank[] = [
  {
    id: "trainee",
    title: "Trainee",
    minXp: 0,
    blurb: "Headset auf, Wissenstab offen, nicht raten.",
  },
  {
    id: "associate",
    title: "Associate",
    minXp: 350,
    blurb: "Du findest Konten, ohne die halbe Datenbank zu durchklicken.",
  },
  {
    id: "specialist",
    title: "Specialist",
    minXp: 900,
    blurb: "Policy sitzt. Kulanz ist ein Werkzeug, kein Reflex.",
  },
  {
    id: "senior",
    title: "Senior",
    minXp: 1700,
    blurb: "QA liebt dich. Betrüger weniger.",
  },
  {
    id: "superstar",
    title: "Superstar",
    minXp: 2800,
    blurb: "CSAT und Compliance in einem Körper. Seltene Spezies.",
  },
]

export function rankForXp(xp: number): Rank {
  return [...RANKS].reverse().find((rank) => xp >= rank.minXp) ?? RANKS[0]
}

export function nextRank(xp: number): Rank | null {
  return RANKS.find((rank) => rank.minXp > xp) ?? null
}

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: "first-shift",
    title: "Erste Schicht",
    description: "Headset überlebt. Kaffee nicht zwingend.",
  },
  {
    id: "perfect-call",
    title: "QA-Liebling",
    description: "Ein Anruf mit 90+ Gesamtwertung.",
  },
  {
    id: "fraud-hunter",
    title: "Fraud Hunter",
    description: "Leere-Box-Trick durchschaut und abgelehnt.",
  },
  {
    id: "empath",
    title: "Ruhepol",
    description: "CSAT 5.0, ohne Policy zu verbiegen.",
  },
  {
    id: "speed",
    title: "AHT-Maschine",
    description: "Einen Fall unter 3 Minuten sauber geschlossen.",
  },
  {
    id: "policy",
    title: "Policy Guardian",
    description: "Verifizierung, Wissen und richtige Aktion in einem Call.",
  },
]

export const STARTER_UNLOCKS = [
  "oma-tracking",
  "wrong-item",
  "porch-pirate",
  "name-collision",
]

export const UNLOCKS_BY_RANK: Record<string, string[]> = {
  associate: ["prime-cancel", "marketplace"],
  specialist: ["empty-box-fraud", "gift-order"],
}

export function defaultCareer(): Career {
  return {
    agentName: "",
    xp: 0,
    shifts: 0,
    callsHandled: 0,
    perfectCalls: 0,
    fraudCaught: 0,
    totalCsat: 0,
    csatSamples: 0,
    achievements: [],
    unlockedCaseIds: [...STARTER_UNLOCKS],
  }
}

export function averageCsat(career: Career) {
  if (career.csatSamples === 0) return 0
  return career.totalCsat / career.csatSamples
}
