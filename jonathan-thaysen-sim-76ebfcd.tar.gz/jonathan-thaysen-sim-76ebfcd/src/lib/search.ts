import type { CaseDefinition, SearchHit } from "./types"

function normalize(value: string) {
  return value.toLowerCase().replace(/[\s.-]/g, "")
}

export function searchCase(caseDef: CaseDefinition, rawQuery: string): SearchHit[] {
  const query = rawQuery.trim()
  if (query.length < 3) return []
  const q = normalize(query)
  const hits: SearchHit[] = []

  for (const customer of caseDef.directory) {
    const fields: { label: string; value: string }[] = [
      { label: "Name", value: customer.name },
      { label: "E-Mail", value: customer.email },
      { label: "Telefon", value: customer.phone },
      { label: "PLZ", value: customer.postcode },
      { label: "Stadt", value: customer.city },
      { label: "Adresse", value: customer.address },
    ]

    const fieldHit = fields.find((field) => normalize(field.value).includes(q))
    if (fieldHit) {
      hits.push({
        customerId: customer.id,
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
        matchedOn: fieldHit.label,
      })
      continue
    }

    const orderHit = caseDef.orders.find(
      (order) =>
        order.customerId === customer.id && normalize(order.id).includes(q)
    )
    if (orderHit) {
      hits.push({
        customerId: customer.id,
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
        matchedOn: "Bestellnummer",
        orderId: orderHit.id,
      })
    }
  }

  return hits
}

export function verifyCustomer(
  caseDef: CaseDefinition,
  customerId: string,
  raw: string
) {
  const customer = caseDef.directory.find((item) => item.id === customerId)
  if (!customer) return false
  const q = normalize(raw)
  if (q.length < 3) return false
  const orders = caseDef.orders.filter((order) => order.customerId === customerId)
  const candidates = [
    customer.email,
    customer.phone,
    customer.phone.replace(/\D/g, "").slice(-4),
    customer.postcode,
    customer.name,
    ...orders.map((order) => order.id),
  ]
  return candidates.some((value) => normalize(value).includes(q) || q.includes(normalize(value)))
}
