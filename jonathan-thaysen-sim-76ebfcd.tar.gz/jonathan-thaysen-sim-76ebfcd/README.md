# PrimeDesk – Amazon Support Simulator

Call-Center-Spiel mit CRM. Du nimmst als Amazon-Support Anrufe an, suchst Konten, liest Bestellungen und triffst Policy-Entscheidungen. Spaß, Druck, QA.

Inoffizielles Trainingsspiel. Keine Verbindung zu Amazon, keine echten Kundendaten.

## Spielen

Jede Schicht hat vier Calls. Das CRM startet leer – so wie am echten Desk.

1. Anruf annehmen.
2. Konto suchen (Mail, Telefon, PLZ, Bestellnummer – nicht nur den Namen).
3. Identität bestätigen.
4. Auftrag und Tracking lesen, bei Bedarf den Wissenstab.
5. Die richtige Aktion buchen: Ersatz, Erstattung, Ablehnen, A-to-Z, Abo pausieren …
6. Notiz schreiben, Wrap-up wählen, nächsten Call nehmen.

Zwei Scores: **CSAT** (Kundengefühl) und **QA** (ob du Policy und Recherche gehalten hast). Ein Betrüger kann 5.0 CSAT haben, während QA durchfällt.

## Lokal starten

```bash
npm install
npm run dev
```

Dev-Server: [http://127.0.0.1:4321](http://127.0.0.1:4321)

Im Browser öffnen, Headset-Namen eintragen, Schicht starten.

## Online (kostenlos)

Vercel Hobby ist kostenlos. Im Cursor-Chat **Publish** klicken oder:

```bash
npx vercel
```

Fortschritt liegt in `localStorage` (`primedesk-career-v1`).

## Stack

Next.js, TypeScript, Tailwind CSS, shadcn/ui.
