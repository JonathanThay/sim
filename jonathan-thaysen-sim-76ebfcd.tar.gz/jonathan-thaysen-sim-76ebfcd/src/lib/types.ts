export type Personality =
  | "angry"
  | "confused"
  | "polite"
  | "scammer"
  | "legal"
  | "chatty"
  | "sweet"

export type QueueName =
  | "Retail"
  | "Prime"
  | "Marketplace"
  | "Digital"
  | "Abos"

export type ActionType =
  | "refund_full"
  | "refund_partial"
  | "replacement"
  | "goodwill"
  | "cancel_order"
  | "resend_tracking"
  | "return_label"
  | "escalate_tier2"
  | "escalate_fraud"
  | "a_to_z_claim"
  | "contact_seller"
  | "refuse"
  | "pause_subscription"
  | "prime_retention"
  | "education_only"

export type CrmView =
  | "search"
  | "customer"
  | "orders"
  | "order"
  | "tracking"
  | "knowledge"
  | "notes"
  | "actions"

export type OrderStatus =
  | "processing"
  | "shipped"
  | "delivered"
  | "returned"
  | "cancelled"
  | "lost"

export type WrapUpCode =
  | "replacement"
  | "refund"
  | "tracking"
  | "goodwill"
  | "policy_decline"
  | "fraud"
  | "escalation"
  | "retention"
  | "marketplace"
  | "subscription"
  | "education"

export type Tone = "empathy" | "neutral" | "cold" | "probe" | "hold"

export type TrackingEvent = {
  at: string
  location: string
  status: string
  note?: string
}

export type OrderItem = {
  id: string
  name: string
  asin: string
  qty: number
  price: number
  hue: number
  seller: string
  fulfilledBy: "Amazon" | "Marketplace"
}

export type Order = {
  id: string
  customerId: string
  placedAt: string
  status: OrderStatus
  items: OrderItem[]
  total: number
  shippingAddress: string
  returnWindowEnds: string
  tracking: TrackingEvent[]
  isGift?: boolean
  giftMessage?: string
  subscription?: boolean
}

export type Customer = {
  id: string
  name: string
  email: string
  phone: string
  address: string
  postcode: string
  city: string
  memberSince: string
  prime: boolean
  ordersCount: number
  returnRate: "niedrig" | "mittel" | "hoch"
  csatHistory: number
  flags: string[]
  accountNotes: string[]
}

export type KnowledgeArticle = {
  id: string
  title: string
  category: string
  summary: string
  body: string
}

export type DialogueChoice = {
  id: string
  text: string
  tone: Tone
  moodDelta: number
  customerReply: string
  nextNodeId: string
  grantsVerify?: boolean
}

export type DialogueNode = {
  id: string
  choices: DialogueChoice[]
}

export type CaseDefinition = {
  id: string
  title: string
  blurb: string
  queue: QueueName
  difficulty: 1 | 2 | 3
  timeLimitSec: number
  personality: Personality
  opening: string[]
  callerId: string
  primaryCustomerId: string
  directory: Customer[]
  orders: Order[]
  knowledgeIds: string[]
  identity: {
    required: boolean
    hint: string
  }
  solution: {
    requiredActions: ActionType[]
    optionalActions: ActionType[]
    forbiddenActions: ActionType[]
    requiredViews: CrmView[]
    mustOpenOrderIds: string[]
    mustOpenTrackingIds: string[]
    mustReadKnowledgeIds: string[]
    mustVerify: boolean
    mustNote: boolean
    wrapUp: WrapUpCode
  }
  actionBeats: Partial<
    Record<ActionType, { customerLine: string; moodDelta: number }>
  >
  coaching: {
    perfect: string
    good: string
    fail: string
    misses: Partial<
      Record<
        | "verify"
        | "views"
        | "actions"
        | "forbidden"
        | "notes"
        | "wrap"
        | "knowledge"
        | "speed"
        | "empathy",
        string
      >
    >
  }
  dialogue: DialogueNode[]
}

export type ChatMessage = {
  id: string
  from: "customer" | "agent" | "system"
  text: string
  atSec: number
}

export type TakenAction = {
  id: string
  type: ActionType
  label: string
  atSec: number
  detail?: string
}

export type SearchHit = {
  customerId: string
  name: string
  email: string
  phone: string
  matchedOn: string
  orderId?: string
}

export type CallScore = {
  investigation: number
  policy: number
  empathy: number
  speed: number
  overall: number
  csat: number
  qaPassed: boolean
  xp: number
  bullets: { ok: boolean; text: string }[]
  coach: string
}

export type CallRecord = {
  caseId: string
  title: string
  score: CallScore
  durationSec: number
  wrapUp?: WrapUpCode
}

export type Career = {
  agentName: string
  xp: number
  shifts: number
  callsHandled: number
  perfectCalls: number
  fraudCaught: number
  totalCsat: number
  csatSamples: number
  achievements: string[]
  unlockedCaseIds: string[]
  lastShiftAt?: string
}

export type Achievement = {
  id: string
  title: string
  description: string
}
