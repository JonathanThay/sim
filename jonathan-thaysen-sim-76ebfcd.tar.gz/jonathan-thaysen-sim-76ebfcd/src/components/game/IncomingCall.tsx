"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { CaseDefinition } from "@/lib/types"
import { Phone, PhoneOff } from "lucide-react"

type Props = {
  caseDef: CaseDefinition
  callIndex: number
  total: number
  agentName: string
  onAccept: () => void
}

export function IncomingCall({
  caseDef,
  callIndex,
  total,
  agentName,
  onAccept,
}: Props) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center px-4 py-12">
      <div className="relative flex w-full max-w-md flex-col items-center gap-6 rounded-2xl bg-card p-8 text-center ring-1 ring-foreground/10">
        <span className="pointer-events-none absolute inset-10 z-0 animate-ping rounded-full bg-primary/20" />
        <Badge className="relative z-10">{caseDef.queue}-Queue</Badge>
        <div className="relative z-10 flex size-24 items-center justify-center rounded-full bg-primary text-primary-foreground">
          <Phone className="size-10" />
        </div>
        <div className="relative z-10">
          <p className="text-xs tracking-widest text-muted-foreground uppercase">
            Eingehender Anruf · {callIndex + 1}/{total}
          </p>
          <h2 className="mt-2 font-heading text-2xl font-semibold">
            Unbekanntes Headset
          </h2>
          <p className="mt-1 font-mono text-sm text-primary">{caseDef.callerId}</p>
        </div>
        <p className="text-sm text-muted-foreground">
          Agent {agentName || "unbenannt"} · CRM ist leer, bis du suchst.
        </p>
        <div className="relative z-10 flex w-full flex-col gap-2">
          <Button size="lg" className="w-full" onClick={onAccept}>
            <Phone data-icon="inline-start" />
            Annehmen
          </Button>
          <Button size="lg" variant="outline" className="w-full" disabled>
            <PhoneOff data-icon="inline-start" />
            Ablehnen
          </Button>
          <p className="text-[11px] text-muted-foreground">
            Ablehnen ist in der Warteschlange nicht vorgesehen. Schön wär&apos;s.
          </p>
        </div>
      </div>
    </div>
  )
}
