import type { KnowledgeArticle } from "./types"

export const KNOWLEDGE: KnowledgeArticle[] = [
  {
    id: "identity",
    title: "Identität prüfen",
    category: "Sicherheit",
    summary: "Vor Erstattung, Ersatz oder Kontodaten immer verifizieren.",
    body: "Mindestens zwei Merkmale abgleichen: E-Mail, Bestellnummer, letzte 4 der Telefonnummer oder PLZ der Lieferadresse. Ohne Verifizierung keine finanziellen Aktionen. Bei abweichendem Anrufer (Geschenk, Partner) keine Zahlungsdaten des Kontoinhabers nennen.",
  },
  {
    id: "delivered-missing",
    title: "Als zugestellt markiert, Kunde hat nichts",
    category: "Versand",
    summary: "Tracking lesen, einmalig Ersatz oder Erstattung, kein Verhör.",
    body: "Sendungsverfolgung vollständig öffnen. Bei „Zugestellt“ ohne Foto: einmalige Kulanz (Ersatz oder volle Erstattung) ist zulässig, wenn das Konto unauffällig ist. Nicht unterstellen, der Kunde lüge. Zweite Meldung in 30 Tagen: Eskalation statt Blind-Refund.",
  },
  {
    id: "wrong-item",
    title: "Falscher Artikel erhalten",
    category: "Bestellung",
    summary: "Ersatz plus Rücksendeetikett, Original nicht behalten lassen.",
    body: "Bestellposition mit dem genannten Artikel abgleichen. Ersatzlieferung auslösen und Rücksendeetikett für den falschen Artikel erzeugen. Keine doppelte Erstattung plus Ersatz. Fotos sind nice-to-have, nicht zwingend.",
  },
  {
    id: "returns-window",
    title: "Rückgabefenster",
    category: "Returns",
    summary: "30 Tage ab Zustellung, Ausnahmen nur mit dokumentierter Kulanz.",
    body: "Standardfenster: 30 Tage nach Zustellung. Prime ändert das Fenster nicht auf 90. Nach Ablauf: höflich ablehnen oder kleine Goodwill-Gutschrift (max. 10 €) bei VIP/erstem Vorfall. Volle Erstattung nach Fenster = Policy-Verstoß.",
  },
  {
    id: "empty-box",
    title: "Leere Box / Return-Betrug",
    category: "Fraud",
    summary: "Serial/Activation und Return-Fotos prüfen, nicht auszahlen.",
    body: "Hinweise: Serial bereits andernorts aktiviert, Rücksendefoto zeigt Leerverpackung, hohe Retourenquote, Druck („ich kenne einen Anwalt“). Keine Erstattung, keine Ersatzlieferung. Fall an Fraud eskalieren, höflich bleiben, Konto vermerken.",
  },
  {
    id: "marketplace",
    title: "Marketplace vs. Amazon",
    category: "Marketplace",
    summary: "Verkäuferfeld lesen. Amazon erstattet nicht die Seller-Kasse.",
    body: "Steht unter dem Artikel ein Drittverkäufer und Fulfillment nicht durch Amazon, darfst du keine Amazon-Erstattung buchen. Optionen: Verkäuferkontakt, A-to-Z-Garantie wenn der Seller nicht reagiert. FBA (Versand durch Amazon) darf Amazon physisch ersetzen.",
  },
  {
    id: "prime-cancel",
    title: "Prime kündigen und Jahresgebühr",
    category: "Prime",
    summary: "Nach 3 Monaten keine volle Jahresrückzahlung.",
    body: "Widerruf der Mitgliedschaft: anteilige Erstattung nur in den ersten 72 Stunden bzw. laut aktueller Staffel maximal die ungenutzten Monate minus 3-Monats-Mindestnutzung. Danach: kündigen zum Laufzeitende, Retention anbieten (Vorteile nennen). Volle 69 € zurück = Policy-Fail.",
  },
  {
    id: "gift-orders",
    title: "Geschenkbestellungen",
    category: "Privacy",
    summary: "Empfänger helfen, Zahlerdaten nie preisgeben.",
    body: "Suche über Bestellnummer oder Empfängeradresse. Ersatz an die Empfängeradresse ist erlaubt. Keine Kreditkarten-, E-Mail- oder Namensdetails des Schenkenden nennen. Rückerstattung geht immer auf das Originalzahlungsmittel des Käufers – das braucht den Kontoinhaber.",
  },
  {
    id: "sns",
    title: "Subscribe & Save Dublette",
    category: "Abos",
    summary: "Doppelte Lieferung erstatten und Rhythmus pausieren.",
    body: "Wenn zwei identische Abo-Sendungen in einem Zyklus rausgingen: die Dublette voll erstatten oder Rücksendung anbieten. Abo auf Pause, nicht komplett kündigen, außer der Kunde will das. Keine Extra-Kulanz nötig.",
  },
  {
    id: "goodwill",
    title: "Goodwill-Richtlinie",
    category: "Kulanz",
    summary: "Kleine Gutschrift, große Probleme nicht zukleistern.",
    body: "Goodwill (5–10 €) ist für Wartezeit, kleine Unannehmlichkeiten, abgelaufenes Fenster bei treuen Konten. Sie ersetzt keine Pflichtleistung (Ersatz bei Falschlieferung). Nicht stapeln: Goodwill plus Vollrefund plus Ersatz ist zu viel.",
  },
]

export function articleById(id: string) {
  return KNOWLEDGE.find((article) => article.id === id)
}
