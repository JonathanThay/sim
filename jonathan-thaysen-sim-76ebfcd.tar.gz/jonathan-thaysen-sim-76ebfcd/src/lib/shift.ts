import { CASES } from "./cases"
import type { CaseDefinition } from "./types"

function shuffle<T>(items: T[]) {
  const copy = [...items]
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[copy[i], copy[j]] = [copy[j], copy[i]]
  }
  return copy
}

export function buildShift(unlockedIds: string[], callsHandled: number) {
  const unlocked = unlockedIds.length > 0 ? unlockedIds : CASES.map((item) => item.id)
  const pool =
    CASES.filter((item) => unlocked.includes(item.id)).length > 0
      ? CASES.filter((item) => unlocked.includes(item.id))
      : CASES
  const size = Math.min(4, pool.length)
  if (callsHandled === 0) {
    const tutorialOrder = [
      "oma-tracking",
      "wrong-item",
      "porch-pirate",
      "name-collision",
    ]
    const tutorial = tutorialOrder
      .map((id) => pool.find((item) => item.id === id))
      .filter((item): item is CaseDefinition => Boolean(item))
      .slice(0, size)
    return tutorial.length > 0 ? tutorial : pool.slice(0, size)
  }
  return shuffle(pool).slice(0, size)
}
