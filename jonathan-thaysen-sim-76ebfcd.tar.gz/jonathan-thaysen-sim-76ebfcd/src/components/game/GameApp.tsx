"use client"

import { IncomingCall } from "@/components/game/IncomingCall"
import { CallDebrief } from "@/components/game/CallDebrief"
import { CallPanel } from "@/components/game/CallPanel"
import { CrmPanel } from "@/components/game/CrmPanel"
import { Lobby } from "@/components/game/Lobby"
import { ShiftDebrief } from "@/components/game/ShiftDebrief"
import { WrapUpDialog } from "@/components/game/WrapUpDialog"
import { startMood } from "@/lib/mood"
import { rankForXp } from "@/lib/ranks"
import { applyCareerProgress, actionLabel, scoreCall } from "@/lib/scoring"
import { searchCase, verifyCustomer } from "@/lib/search"
import { buildShift } from "@/lib/shift"
import { resetCareer, saveCareer, useCareer } from "@/lib/storage"
import type {
  ActionType,
  CallRecord,
  Career,
  CaseDefinition,
  ChatMessage,
  CrmView,
  DialogueChoice,
  SearchHit,
  TakenAction,
  WrapUpCode,
} from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Headset, MessageSquare, PanelRight } from "lucide-react"
import { useEffect, useMemo, useRef, useState } from "react"
import { toast } from "sonner"

type Phase = "lobby" | "incoming" | "call" | "debrief" | "shift-end"

type CallRuntime = {
  elapsedSec: number
  mood: number
  onHold: boolean
  verified: boolean
  hungUp: boolean
  typing: boolean
  nodeId: string
  messages: ChatMessage[]
  views: CrmView[]
  openedOrderIds: string[]
  openedTrackingIds: string[]
  openedKbIds: string[]
  query: string
  hits: SearchHit[]
  customerId: string | null
  selectedOrderId: string | null
  actions: TakenAction[]
  notes: string
  wrapUp?: WrapUpCode
  verifyValue: string
  lastAgentSec: number
  nudged: boolean
}

const emptyCall = (): CallRuntime => ({
  elapsedSec: 0,
  mood: 60,
  onHold: false,
  verified: false,
  hungUp: false,
  typing: false,
  nodeId: "start",
  messages: [],
  views: ["search"],
  openedOrderIds: [],
  openedTrackingIds: [],
  openedKbIds: [],
  query: "",
  hits: [],
  customerId: null,
  selectedOrderId: null,
  actions: [],
  notes: "",
  verifyValue: "",
  lastAgentSec: 0,
  nudged: false,
})

function uid() {
  return Math.random().toString(36).slice(2, 9)
}

export function GameApp() {
  const career = useCareer()
  const [phase, setPhase] = useState<Phase>("lobby")
  const [nameDraft, setNameDraft] = useState<string | null>(null)
  const [shift, setShift] = useState<CaseDefinition[]>([])
  const [callIndex, setCallIndex] = useState(0)
  const [records, setRecords] = useState<CallRecord[]>([])
  const [careerBefore, setCareerBefore] = useState<Career>(career)
  const [call, setCall] = useState<CallRuntime>(emptyCall)
  const [wrapOpen, setWrapOpen] = useState(false)
  const [mobilePane, setMobilePane] = useState<"call" | "crm">("call")
  const [crmTab, setCrmTab] = useState("customer")
  const [lastCareer, setLastCareer] = useState<Career>(career)
  const replyTimer = useRef<number | null>(null)
  const agentName = nameDraft ?? career.agentName

  const caseDef = shift[callIndex]
  const currentRecord = records[records.length - 1]

  useEffect(() => {
    if (phase !== "call" || call.hungUp) return
    const timer = window.setInterval(() => {
      setCall((prev) => {
        if (prev.hungUp) return prev
        const decay = prev.onHold ? 0.18 : 0.28
        const mood = Math.max(0, prev.mood - decay)
        const elapsedSec = prev.elapsedSec + 1
        const hungUp = mood <= 6
        const next: CallRuntime = { ...prev, elapsedSec, mood, hungUp }
        if (
          !prev.nudged &&
          !prev.onHold &&
          elapsedSec - prev.lastAgentSec >= 28 &&
          !hungUp
        ) {
          next.nudged = true
          next.messages = [
            ...prev.messages,
            {
              id: uid(),
              from: "customer",
              text: "Hallo? Sind Sie noch da?",
              atSec: elapsedSec,
            },
          ]
          next.mood = Math.max(0, mood - 6)
        }
        if (hungUp && !prev.hungUp) {
          next.messages = [
            ...prev.messages,
            {
              id: uid(),
              from: "system",
              text: "Kunde hat aufgelegt",
              atSec: elapsedSec,
            },
          ]
        }
        return next
      })
    }, 1000)
    return () => window.clearInterval(timer)
  }, [phase, call.hungUp])

  useEffect(() => {
    return () => {
      if (replyTimer.current) window.clearTimeout(replyTimer.current)
    }
  }, [])

  const displayName = agentName.trim() || "Sam Nowak"
  const rank = rankForXp(career.xp)

  const node = useMemo(() => {
    if (!caseDef) return undefined
    return caseDef.dialogue.find((item) => item.id === call.nodeId)
  }, [caseDef, call.nodeId])

  function persist(next: Career) {
    saveCareer(next)
  }

  function startShift() {
    try {
      const named = {
        ...career,
        agentName: displayName,
      }
      const queue = buildShift(named.unlockedCaseIds, named.callsHandled)
      if (queue.length === 0) {
        toast.error("Keine Fälle freigeschaltet.")
        return
      }
      setCareerBefore(named)
      setShift(queue)
      setCallIndex(0)
      setRecords([])
      setPhase("incoming")
      persist(named)
    } catch (error) {
      console.error(error)
      toast.error("Schicht konnte nicht starten. Bitte Seite neu laden.")
    }
  }

  function beginCall() {
    if (!caseDef) return
    const opening = caseDef.opening.map((text, index) => ({
      id: uid(),
      from: "customer" as const,
      text,
      atSec: index,
    }))
    setCall({
      ...emptyCall(),
      mood: startMood(caseDef.personality),
      messages: [
        {
          id: uid(),
          from: "system",
          text: `Verbunden · ${caseDef.queue}-Queue`,
          atSec: 0,
        },
        ...opening,
      ],
    })
    setCrmTab("customer")
    setMobilePane("call")
    setWrapOpen(false)
    setPhase("call")
  }

  function pushCustomer(text: string, delay = 650) {
    setCall((prev) => ({ ...prev, typing: true }))
    if (replyTimer.current) window.clearTimeout(replyTimer.current)
    replyTimer.current = window.setTimeout(() => {
      setCall((prev) => ({
        ...prev,
        typing: false,
        messages: [
          ...prev.messages,
          { id: uid(), from: "customer", text, atSec: prev.elapsedSec },
        ],
      }))
    }, delay)
  }

  function handleChoice(choice: DialogueChoice) {
    if (!caseDef || call.hungUp || call.typing) return
    setCall((prev) => ({
      ...prev,
      mood: Math.max(0, Math.min(100, prev.mood + choice.moodDelta)),
      verified: prev.verified || Boolean(choice.grantsVerify),
      lastAgentSec: prev.elapsedSec,
      nodeId: choice.nextNodeId,
      messages: [
        ...prev.messages,
        {
          id: uid(),
          from: "agent",
          text: choice.text,
          atSec: prev.elapsedSec,
        },
      ],
    }))
    if (choice.grantsVerify) toast.success("Identität über das Gespräch bestätigt.")
    pushCustomer(choice.customerReply)
  }

  function handleSearch() {
    if (!caseDef) return
    const hits = searchCase(caseDef, call.query)
    setCall((prev) => ({
      ...prev,
      hits,
      views: uniqView(prev.views, "search"),
    }))
    if (hits.length === 0) toast.error("Kein Treffer. Anderes Merkmal versuchen.")
  }

  function openCustomer(customerId: string, orderId?: string) {
    if (!caseDef) return
    const orders = caseDef.orders.filter((order) => order.customerId === customerId)
    const selected = orderId ?? orders[0]?.id ?? null
    setCall((prev) => ({
      ...prev,
      customerId,
      selectedOrderId: selected,
      hits: [],
      views: uniqView(prev.views, "customer"),
      openedOrderIds: selected
        ? uniq(prev.openedOrderIds, selected)
        : prev.openedOrderIds,
    }))
    setCrmTab("customer")
    const person = caseDef.directory.find((item) => item.id === customerId)
    toast.message(`Konto geladen: ${person?.name ?? customerId}`)
  }

  function openOrder(orderId: string) {
    setCall((prev) => ({
      ...prev,
      selectedOrderId: orderId,
      views: uniqView(uniqView(prev.views, "orders"), "order"),
      openedOrderIds: uniq(prev.openedOrderIds, orderId),
      openedTrackingIds: uniq(prev.openedTrackingIds, orderId),
    }))
    setCrmTab("order")
  }

  function openTracking(orderId: string) {
    setCall((prev) => ({
      ...prev,
      selectedOrderId: orderId,
      views: uniqView(uniqView(prev.views, "order"), "tracking"),
      openedTrackingIds: uniq(prev.openedTrackingIds, orderId),
      openedOrderIds: uniq(prev.openedOrderIds, orderId),
    }))
    setCrmTab("order")
    toast.success("Sendungsverlauf gelesen.")
  }

  function openKb(id: string) {
    setCall((prev) => ({
      ...prev,
      openedKbIds: uniq(prev.openedKbIds, id),
      views: uniqView(prev.views, "knowledge"),
    }))
  }

  function handleVerify() {
    if (!caseDef || !call.customerId) return
    const ok = verifyCustomer(caseDef, call.customerId, call.verifyValue)
    if (ok) {
      setCall((prev) => ({ ...prev, verified: true }))
      toast.success("Identität bestätigt.")
    } else {
      toast.error("Merkmale passen nicht. Mail, PLZ, Last-4 oder Bestellnr.")
    }
  }

  function handleAction(type: ActionType) {
    if (!caseDef || call.hungUp) return
    if (call.actions.some((action) => action.type === type)) {
      toast.message("Die Aktion ist in diesem Call schon gebucht.")
      return
    }
    const taken: TakenAction = {
      id: uid(),
      type,
      label: actionLabel(type),
      atSec: call.elapsedSec,
    }
    setCall((prev) => ({
      ...prev,
      actions: [...prev.actions, taken],
      views: uniqView(prev.views, "actions"),
    }))
    toast.message(`${actionLabel(type)} gebucht.`)
    const beat = caseDef.actionBeats[type]
    if (beat) {
      setCall((prev) => ({
        ...prev,
        mood: Math.max(0, Math.min(100, prev.mood + beat.moodDelta)),
      }))
      pushCustomer(beat.customerLine, 500)
    }
  }

  function finishCall() {
    if (!caseDef) return
    const customer = caseDef.directory.find((item) => item.id === call.customerId)
    const score = scoreCall({
      caseDef,
      views: call.views,
      openedOrderIds: call.openedOrderIds,
      openedTrackingIds: call.openedTrackingIds,
      openedKbIds: call.openedKbIds,
      verified: call.verified,
      notes: call.notes,
      actions: call.actions,
      wrapUp: call.wrapUp,
      mood: call.hungUp ? Math.min(call.mood, 25) : call.mood,
      elapsedSec: call.elapsedSec,
      loadedRightCustomer: customer?.id === caseDef.primaryCustomerId,
    })
    const record: CallRecord = {
      caseId: caseDef.id,
      title: caseDef.title,
      score,
      durationSec: call.elapsedSec,
      wrapUp: call.wrapUp,
    }
    setRecords((prev) => [...prev, record])
    setWrapOpen(false)
    setPhase("debrief")
  }

  function nextAfterDebrief() {
    if (callIndex + 1 >= shift.length) {
      const snapshot = records
      const nextCareer = applyCareerProgress(
        careerBefore,
        snapshot.map((record) => ({
          caseId: record.caseId,
          score: record.score,
          durationSec: record.durationSec,
        }))
      )
      nextCareer.agentName = displayName
      setLastCareer(careerBefore)
      persist(nextCareer)
      setPhase("shift-end")
      return
    }
    setCallIndex((index) => index + 1)
    setPhase("incoming")
  }

  const customer = caseDef?.directory.find((item) => item.id === call.customerId) ?? null
  const newAchievements = career.achievements.filter(
    (id) => !lastCareer.achievements.includes(id)
  )

  if (phase === "lobby") {
    return (
      <Lobby
        career={career}
        agentName={agentName}
        onName={(name) => setNameDraft(name)}
        onStart={startShift}
        onReset={() => {
          resetCareer()
          setNameDraft("")
          toast.message("Karriere gelöscht.")
        }}
      />
    )
  }

  if (phase === "incoming" && caseDef) {
    return (
      <IncomingCall
        caseDef={caseDef}
        callIndex={callIndex}
        total={shift.length}
        agentName={displayName}
        onAccept={beginCall}
      />
    )
  }

  if (phase === "debrief" && currentRecord) {
    return (
      <CallDebrief
        record={currentRecord}
        remaining={shift.length - callIndex - 1}
        onNext={nextAfterDebrief}
      />
    )
  }

  if (phase === "shift-end") {
    return (
      <ShiftDebrief
        records={records}
        before={lastCareer}
        after={career}
        newAchievements={newAchievements}
        onLobby={() => setPhase("lobby")}
      />
    )
  }

  if (phase === "call" && caseDef) {
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-3 border-b bg-card px-3 py-2 text-xs">
          <div className="flex items-center gap-2">
            <Headset className="size-4 text-primary" />
            <span className="font-heading text-sm font-semibold">PrimeDesk</span>
            <span className="hidden text-muted-foreground sm:inline">
              {displayName} · {rank.title}
            </span>
          </div>
          <div className="flex items-center gap-3 tabular-nums text-muted-foreground">
            <span>
              Call {callIndex + 1}/{shift.length}
            </span>
            <span className="hidden sm:inline">{caseDef.queue}</span>
          </div>
        </header>

        <div className="flex border-b md:hidden">
          <Button
            variant={mobilePane === "call" ? "secondary" : "ghost"}
            className="flex-1 rounded-none"
            onClick={() => setMobilePane("call")}
          >
            <MessageSquare data-icon="inline-start" />
            Gespräch
          </Button>
          <Button
            variant={mobilePane === "crm" ? "secondary" : "ghost"}
            className="flex-1 rounded-none"
            onClick={() => setMobilePane("crm")}
          >
            <PanelRight data-icon="inline-start" />
            CRM
          </Button>
        </div>

        <div className="grid min-h-0 flex-1 md:grid-cols-[minmax(280px,38%)_1fr]">
          <div
            className={`min-h-0 ${mobilePane === "call" ? "flex" : "hidden"} md:flex`}
          >
            <CallPanel
              caseDef={caseDef}
              agentName={displayName}
              elapsedSec={call.elapsedSec}
              mood={call.mood}
              onHold={call.onHold}
              typing={call.typing}
              messages={call.messages}
              choices={node?.choices ?? []}
              hungUp={call.hungUp}
              onChoice={handleChoice}
              onHoldToggle={() =>
                setCall((prev) => ({
                  ...prev,
                  onHold: !prev.onHold,
                  messages: [
                    ...prev.messages,
                    {
                      id: uid(),
                      from: "system",
                      text: prev.onHold ? "Hold beendet" : "Kunde auf Hold",
                      atSec: prev.elapsedSec,
                    },
                  ],
                }))
              }
              onWrap={() => setWrapOpen(true)}
            />
          </div>
          <div
            className={`min-h-0 ${mobilePane === "crm" ? "flex" : "hidden"} md:flex`}
          >
            <CrmPanel
              caseDef={caseDef}
              query={call.query}
              onQuery={(value) => setCall((prev) => ({ ...prev, query: value }))}
              onSearch={handleSearch}
              onSearchAni={() => {
                setCall((prev) => ({ ...prev, query: caseDef.callerId }))
                const hits = searchCase(caseDef, caseDef.callerId)
                setCall((prev) => ({
                  ...prev,
                  query: caseDef.callerId,
                  hits,
                  views: uniqView(prev.views, "search"),
                }))
              }}
              hits={call.hits}
              customer={customer}
              onOpenCustomer={openCustomer}
              selectedOrderId={call.selectedOrderId}
              onOpenOrder={openOrder}
              onOpenTracking={openTracking}
              onOpenKb={openKb}
              openedKbIds={call.openedKbIds}
              verifyValue={call.verifyValue}
              onVerifyValue={(value) =>
                setCall((prev) => ({ ...prev, verifyValue: value }))
              }
              onVerify={handleVerify}
              verified={call.verified}
              notes={call.notes}
              onNotes={(value) =>
                setCall((prev) => ({
                  ...prev,
                  notes: value,
                  views: uniqView(prev.views, "notes"),
                }))
              }
              onAction={handleAction}
              actions={call.actions}
              tab={crmTab}
              onTab={(tab) => {
                setCrmTab(tab)
                const mapped = tab as CrmView
                if (
                  mapped === "customer" ||
                  mapped === "orders" ||
                  mapped === "order" ||
                  mapped === "knowledge" ||
                  mapped === "notes" ||
                  mapped === "actions"
                ) {
                  setCall((prev) => ({
                    ...prev,
                    views: uniqView(prev.views, mapped),
                  }))
                }
              }}
            />
          </div>
        </div>

        <WrapUpDialog
          open={wrapOpen}
          onOpenChange={setWrapOpen}
          selected={call.wrapUp}
          onSelect={(code) => setCall((prev) => ({ ...prev, wrapUp: code }))}
          onConfirm={finishCall}
        />
      </div>
    )
  }

  return null
}

function uniq(list: string[], item: string) {
  return list.includes(item) ? list : [...list, item]
}

function uniqView(list: CrmView[], item: CrmView) {
  return list.includes(item) ? list : [...list, item]
}
