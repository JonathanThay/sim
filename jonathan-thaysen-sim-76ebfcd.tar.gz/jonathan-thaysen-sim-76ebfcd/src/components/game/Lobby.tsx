"use client"

import { ACHIEVEMENTS, averageCsat, nextRank, rankForXp } from "@/lib/ranks"
import { CASES } from "@/lib/cases"
import type { Career } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  Headset,
  Search,
  ShieldCheck,
  Heart,
  Timer,
  Lock,
  Sparkles,
} from "lucide-react"

type Props = {
  career: Career
  agentName: string
  onName: (name: string) => void
  onStart: () => void
  onReset: () => void
}

export function Lobby({ career, agentName, onName, onStart, onReset }: Props) {
  const rank = rankForXp(career.xp)
  const upcoming = nextRank(career.xp)
  const progress = upcoming
    ? ((career.xp - rank.minXp) / (upcoming.minXp - rank.minXp)) * 100
    : 100
  const csat = averageCsat(career)

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 py-8 md:py-12">
      <header className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div className="space-y-3">
          <p className="text-xs font-medium tracking-[0.22em] text-primary uppercase">
            Inoffizielle Support-Akademie
          </p>
          <h1 className="font-heading text-4xl font-semibold tracking-tight md:text-5xl">
            PrimeDesk
            <span className="mt-1 block h-1.5 w-36 rounded-full bg-primary" />
          </h1>
          <p className="max-w-xl text-base text-muted-foreground">
            Du bist Amazon-Support. Vier Anrufe, ein CRM, kein Autopilot.
            Finde das richtige Konto, lies die Bestellung, folge der Policy –
            und bleib menschlich.
          </p>
        </div>
        <div className="flex w-full max-w-sm flex-col gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <label className="text-xs font-medium text-muted-foreground">
            Agentenname auf dem Headset
          </label>
          <Input
            value={agentName}
            placeholder="z. B. Sam Nowak"
            onChange={(event) => onName(event.target.value)}
            maxLength={32}
          />
          <Button size="lg" className="w-full" onClick={onStart}>
            <Headset data-icon="inline-start" />
            Schicht starten · 4 Calls
          </Button>
        </div>
      </header>

      <section className="grid gap-4 md:grid-cols-4">
        <Stat
          icon={ShieldCheck}
          label="Rang"
          value={rank.title}
          hint={rank.blurb}
        />
        <Stat
          icon={Sparkles}
          label="XP"
          value={String(career.xp)}
          hint={
            upcoming
              ? `noch ${upcoming.minXp - career.xp} bis ${upcoming.title}`
              : "Maximales Rangband"
          }
        />
        <Stat
          icon={Heart}
          label="CSAT"
          value={career.csatSamples ? csat.toFixed(2) : "–"}
          hint={`${career.callsHandled} Calls · ${career.shifts} Schichten`}
        />
        <Stat
          icon={Timer}
          label="QA-Perfekt"
          value={String(career.perfectCalls)}
          hint={
            career.fraudCaught
              ? `${career.fraudCaught}× Betrug gestoppt`
              : "Noch kein Fraud-Fang"
          }
        />
      </section>

      <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Rangfortschritt</span>
          <span className="tabular-nums">
            {career.xp}
            {upcoming ? ` / ${upcoming.minXp}` : ""}
          </span>
        </div>
        <Progress value={progress} />
      </div>

      <section className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <CardHeader>
            <CardTitle>So gewinnst du</CardTitle>
            <CardDescription>
              CSAT misst den Kunden. QA misst dich. Betrüger dürfen happy sein –
              du nicht mit ihnen.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2">
            <Skill
              icon={Search}
              title="Recherche"
              text="ANI ist nur der Einstieg. Suche per Bestellnummer, Mail oder PLZ. Namenskollisionen sind Absicht."
            />
            <Skill
              icon={ShieldCheck}
              title="Policy"
              text="Verifizieren, Wissenstab lesen, dann buchen. Marketplace ist nicht Amazon-Kasse."
            />
            <Skill
              icon={Heart}
              title="Empathie"
              text="Wut zuerst anerkennen. Oma nicht hetzen. Scammer höflich abweisen."
            />
            <Skill
              icon={Timer}
              title="Tempo"
              text="Hold ist erlaubt, Schweigen nicht. Nach dem Resolve: Notiz, Wrap-up, nächster Call."
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Badges</CardTitle>
            <CardDescription>Kleine Eitelkeiten für große QA-Werte.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-2">
            {ACHIEVEMENTS.map((item) => {
              const owned = career.achievements.includes(item.id)
              return (
                <div
                  key={item.id}
                  className="flex items-start gap-3 rounded-lg bg-muted/50 px-3 py-2"
                >
                  {owned ? (
                    <Sparkles className="mt-0.5 size-4 text-primary" />
                  ) : (
                    <Lock className="mt-0.5 size-4 text-muted-foreground" />
                  )}
                  <div>
                    <p className="text-sm font-medium">{item.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-heading text-lg font-medium">Fallbibliothek</h2>
          <p className="text-xs text-muted-foreground">
            Härtere Queues schalten mit dem Rang frei.
          </p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {CASES.map((item) => {
            const open = career.unlockedCaseIds.includes(item.id)
            return (
              <div
                key={item.id}
                className="rounded-xl bg-card p-4 ring-1 ring-foreground/10"
              >
                <div className="mb-2 flex items-center justify-between gap-2">
                  <Badge variant={open ? "default" : "secondary"}>
                    {open ? item.queue : "Gesperrt"}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {"●".repeat(item.difficulty)}
                    <span className="opacity-30">
                      {"●".repeat(3 - item.difficulty)}
                    </span>
                  </span>
                </div>
                <p className="text-sm font-medium">{item.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {open ? item.blurb : "Steigt mit XP frei."}
                </p>
              </div>
            )
          })}
        </div>
      </section>

      <footer className="flex flex-col gap-2 border-t pt-4 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
        <p>
          Inoffizielles Trainingsspiel. Keine echten Kundendaten, keine Verbindung
          zu Amazon.
        </p>
        <Button variant="ghost" size="sm" onClick={onReset}>
          Karriere zurücksetzen
        </Button>
      </footer>
    </div>
  )
}

function Stat({
  icon: Icon,
  label,
  value,
  hint,
}: {
  icon: typeof Headset
  label: string
  value: string
  hint: string
}) {
  return (
    <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <div className="mb-2 flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </div>
      <p className="text-xl font-semibold tracking-tight">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </div>
  )
}

function Skill({
  icon: Icon,
  title,
  text,
}: {
  icon: typeof Search
  title: string
  text: string
}) {
  return (
    <div className="rounded-lg bg-muted/40 p-3">
      <div className="mb-1 flex items-center gap-2 text-sm font-medium">
        <Icon className="size-4 text-primary" />
        {title}
      </div>
      <p className="text-xs leading-5 text-muted-foreground">{text}</p>
    </div>
  )
}
