"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { deDate, deDateTime, eur } from "@/lib/format"
import { KNOWLEDGE } from "@/lib/knowledge"
import { actionLabel } from "@/lib/scoring"
import type {
  ActionType,
  CaseDefinition,
  Customer,
  Order,
  SearchHit,
  TakenAction,
} from "@/lib/types"
import {
  BookOpen,
  Package,
  Search,
  ShieldCheck,
  StickyNote,
  Truck,
  User,
  Zap,
} from "lucide-react"

type Props = {
  caseDef: CaseDefinition
  query: string
  onQuery: (value: string) => void
  onSearch: () => void
  onSearchAni: () => void
  hits: SearchHit[]
  customer: Customer | null
  onOpenCustomer: (customerId: string, orderId?: string) => void
  selectedOrderId: string | null
  onOpenOrder: (orderId: string) => void
  onOpenTracking: (orderId: string) => void
  onOpenKb: (id: string) => void
  openedKbIds: string[]
  verifyValue: string
  onVerifyValue: (value: string) => void
  onVerify: () => void
  verified: boolean
  notes: string
  onNotes: (value: string) => void
  onAction: (type: ActionType, detail?: string) => void
  actions: TakenAction[]
  tab: string
  onTab: (tab: string) => void
}

const ACTION_GROUPS: { title: string; items: ActionType[] }[] = [
  {
    title: "Lösung",
    items: [
      "replacement",
      "refund_full",
      "refund_partial",
      "return_label",
      "resend_tracking",
      "pause_subscription",
      "cancel_order",
    ],
  },
  {
    title: "Kulanz & Gespräch",
    items: ["goodwill", "prime_retention", "education_only", "refuse"],
  },
  {
    title: "Weitergabe",
    items: ["contact_seller", "a_to_z_claim", "escalate_tier2", "escalate_fraud"],
  },
]

export function CrmPanel(props: Props) {
  const orders = props.customer
    ? props.caseDef.orders.filter((order) => order.customerId === props.customer?.id)
    : []
  const selected =
    orders.find((order) => order.id === props.selectedOrderId) ?? orders[0]

  return (
    <section className="flex h-full min-h-0 w-full flex-col bg-background">
      <header className="border-b px-4 py-3">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-sm font-medium">CRM · Kundenverzeichnis</p>
          {props.verified ? (
            <Badge>Identität bestätigt</Badge>
          ) : (
            <Badge variant="outline">Nicht verifiziert</Badge>
          )}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(event) => {
            event.preventDefault()
            props.onSearch()
          }}
        >
          <Input
            value={props.query}
            onChange={(event) => props.onQuery(event.target.value)}
            placeholder="Name, Mail, Telefon, PLZ, Bestellnr."
          />
          <Button type="submit">
            <Search data-icon="inline-start" />
            Suchen
          </Button>
        </form>
        {props.hits.length > 0 ? (
          <div className="mt-2 grid gap-1">
            {props.hits.map((hit) => (
              <button
                key={`${hit.customerId}-${hit.orderId ?? "c"}`}
                type="button"
                onClick={() => props.onOpenCustomer(hit.customerId, hit.orderId)}
                className="flex items-center justify-between rounded-lg bg-muted/60 px-3 py-2 text-left text-sm hover:bg-muted"
              >
                <span>
                  <span className="font-medium">{hit.name}</span>
                  <span className="ml-2 text-xs text-muted-foreground">
                    {hit.email}
                  </span>
                </span>
                <span className="text-xs text-primary">{hit.matchedOn}</span>
              </button>
            ))}
          </div>
        ) : null}
      </header>

      {!props.customer ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 text-center">
          <Search className="size-8 text-muted-foreground" />
          <p className="text-sm font-medium">Kein Konto geladen</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            Die Nummer auf dem Display ist nur der Einstieg. Suche wie im echten
            Desk: Bestellnummer schlägt Namen, PLZ schlägt Namensvettern.
          </p>
          <Button variant="outline" size="sm" onClick={props.onSearchAni}>
            ANI übernehmen · {props.caseDef.callerId}
          </Button>
        </div>
      ) : (
        <Tabs
          value={props.tab}
          onValueChange={(value) => props.onTab(String(value))}
          className="flex min-h-0 flex-1 flex-col gap-0"
        >
          <div className="overflow-x-auto border-b px-2 py-2">
            <TabsList variant="line" className="w-max">
              <TabsTrigger value="customer">
                <User data-icon="inline-start" />
                Kunde
              </TabsTrigger>
              <TabsTrigger value="orders">
                <Package data-icon="inline-start" />
                Bestellungen
              </TabsTrigger>
              <TabsTrigger value="order">
                <Truck data-icon="inline-start" />
                Auftrag
              </TabsTrigger>
              <TabsTrigger value="actions">
                <Zap data-icon="inline-start" />
                Aktionen
              </TabsTrigger>
              <TabsTrigger value="knowledge">
                <BookOpen data-icon="inline-start" />
                Wissen
              </TabsTrigger>
              <TabsTrigger value="notes">
                <StickyNote data-icon="inline-start" />
                Notizen
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto">
            <TabsContent value="customer" className="p-4">
              <CustomerPane
                customer={props.customer}
                verifyValue={props.verifyValue}
                onVerifyValue={props.onVerifyValue}
                onVerify={props.onVerify}
                verified={props.verified}
                hint={props.caseDef.identity.hint}
              />
            </TabsContent>
            <TabsContent value="orders" className="p-4">
              <OrdersPane
                orders={orders}
                selectedId={selected?.id}
                onOpen={props.onOpenOrder}
              />
            </TabsContent>
            <TabsContent value="order" className="p-4">
              {selected ? (
                <OrderPane
                  order={selected}
                  onTracking={() => props.onOpenTracking(selected.id)}
                />
              ) : (
                <p className="text-sm text-muted-foreground">Keine Bestellung.</p>
              )}
            </TabsContent>
            <TabsContent value="actions" className="p-4">
              <ActionsPane
                onAction={props.onAction}
                actions={props.actions}
                verified={props.verified}
              />
            </TabsContent>
            <TabsContent value="knowledge" className="p-4">
              <KnowledgePane
                ids={props.caseDef.knowledgeIds}
                opened={props.openedKbIds}
                onOpen={props.onOpenKb}
              />
            </TabsContent>
            <TabsContent value="notes" className="p-4">
              <div className="space-y-2">
                <Label htmlFor="notes">Fallnotiz für QA</Label>
                <textarea
                  id="notes"
                  value={props.notes}
                  onChange={(event) => props.onNotes(event.target.value)}
                  rows={8}
                  className="w-full rounded-lg border border-input bg-transparent p-3 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50"
                  placeholder="Was war das Anliegen, was hast du im System gesehen, was gebucht?"
                />
                <p className="text-xs text-muted-foreground">
                  Mindestens ein klarer Satz. QA liest das wirklich.
                </p>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      )}
    </section>
  )
}

function CustomerPane({
  customer,
  verifyValue,
  onVerifyValue,
  onVerify,
  verified,
  hint,
}: {
  customer: Customer
  verifyValue: string
  onVerifyValue: (value: string) => void
  onVerify: () => void
  verified: boolean
  hint: string
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-heading text-lg font-medium">{customer.name}</h3>
          <p className="text-xs text-muted-foreground">
            Kunde seit {deDate(customer.memberSince)} · {customer.ordersCount}{" "}
            Bestellungen
          </p>
        </div>
        <div className="flex flex-wrap justify-end gap-1">
          {customer.prime ? <Badge>Prime</Badge> : null}
          {customer.flags.map((flag) => (
            <Badge key={flag} variant="secondary">
              {flag}
            </Badge>
          ))}
        </div>
      </div>
      <dl className="grid grid-cols-2 gap-3 text-sm">
        <Field label="E-Mail" value={customer.email} />
        <Field label="Telefon" value={customer.phone} />
        <Field
          label="Adresse"
          value={`${customer.address}, ${customer.postcode} ${customer.city}`}
        />
        <Field label="Retourenquote" value={customer.returnRate} />
        <Field label="Historische CSAT" value={customer.csatHistory.toFixed(1)} />
      </dl>
      {customer.accountNotes.length > 0 ? (
        <div className="rounded-lg bg-amber-500/10 p-3 text-sm">
          <p className="mb-1 text-xs font-medium text-amber-600 dark:text-amber-400">
            Account-Notizen
          </p>
          <ul className="list-disc space-y-1 pl-4 text-xs">
            {customer.accountNotes.map((note) => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        </div>
      ) : null}
      <form
        className="space-y-2 rounded-lg bg-muted/40 p-3"
        onSubmit={(event) => {
          event.preventDefault()
          onVerify()
        }}
      >
        <div className="flex items-center gap-2 text-sm font-medium">
          <ShieldCheck className="size-4 text-primary" />
          Identität bestätigen
        </div>
        <p className="text-xs text-muted-foreground">{hint}</p>
        <div className="flex gap-2">
          <Input
            value={verifyValue}
            onChange={(event) => onVerifyValue(event.target.value)}
            placeholder="Mail, PLZ, Last-4 oder Bestellnr."
            disabled={verified}
          />
          <Button type="submit" disabled={verified}>
            Check
          </Button>
        </div>
      </form>
    </div>
  )
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  )
}

function OrdersPane({
  orders,
  selectedId,
  onOpen,
}: {
  orders: Order[]
  selectedId?: string
  onOpen: (id: string) => void
}) {
  if (orders.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Keine Bestellungen auf diesem Konto. Vielleicht liegt der Auftrag woanders.
      </p>
    )
  }
  return (
    <div className="grid gap-2">
      {orders.map((order) => (
        <button
          key={order.id}
          type="button"
          onClick={() => onOpen(order.id)}
          className={`rounded-lg border p-3 text-left ${
            selectedId === order.id ? "border-primary bg-primary/5" : "border-border"
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="font-mono text-xs">{order.id}</span>
            <Badge variant="secondary">{statusLabel(order.status)}</Badge>
          </div>
          <p className="mt-1 text-sm font-medium">{order.items[0]?.name}</p>
          <p className="text-xs text-muted-foreground">
            {deDate(order.placedAt)} · {eur(order.total)}
            {order.subscription ? " · Abo" : ""}
            {order.isGift ? " · Geschenk" : ""}
          </p>
        </button>
      ))}
    </div>
  )
}

function OrderPane({
  order,
  onTracking,
}: {
  order: Order
  onTracking: () => void
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-xs text-muted-foreground">{order.id}</p>
          <h3 className="font-heading text-base font-medium">
            {statusLabel(order.status)} · {eur(order.total)}
          </h3>
        </div>
        <Button size="sm" variant="outline" onClick={onTracking}>
          Tracking lesen
        </Button>
      </div>
      <dl className="grid grid-cols-2 gap-3 text-sm">
        <Field label="Bestellt" value={deDateTime(order.placedAt)} />
        <Field label="Retourfenster bis" value={deDate(order.returnWindowEnds)} />
        <Field label="Lieferadresse" value={order.shippingAddress} />
        <Field
          label="Versand"
          value={order.items[0]?.fulfilledBy === "Amazon" ? "Amazon" : "Seller"}
        />
      </dl>
      {order.isGift ? (
        <p className="rounded-lg bg-muted p-3 text-xs">
          Geschenkbestellung
          {order.giftMessage ? ` · „${order.giftMessage}“` : ""}
        </p>
      ) : null}
      <div className="space-y-2">
        {order.items.map((item) => (
          <div key={item.id} className="flex gap-3 rounded-lg border p-3">
            <div
              className="size-12 shrink-0 rounded-md"
              style={{ background: `oklch(0.7 0.12 ${item.hue})` }}
            />
            <div className="min-w-0">
              <p className="text-sm font-medium">{item.name}</p>
              <p className="text-xs text-muted-foreground">
                {item.asin} · {item.seller} · {item.fulfilledBy}
              </p>
              <p className="text-xs">
                {item.qty} × {eur(item.price)}
              </p>
            </div>
          </div>
        ))}
      </div>
      <div>
        <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
          Sendungsverlauf
        </p>
        <ol className="space-y-2 border-l pl-3">
          {order.tracking.map((event) => (
            <li key={event.at} className="text-sm">
              <p className="font-medium">{event.status}</p>
              <p className="text-xs text-muted-foreground">
                {deDateTime(event.at)} · {event.location}
              </p>
              {event.note ? (
                <p className="mt-1 text-xs text-amber-600 dark:text-amber-400">
                  {event.note}
                </p>
              ) : null}
            </li>
          ))}
        </ol>
      </div>
    </div>
  )
}

function ActionsPane({
  onAction,
  actions,
  verified,
}: {
  onAction: (type: ActionType, detail?: string) => void
  actions: TakenAction[]
  verified: boolean
}) {
  return (
    <div className="space-y-5">
      {!verified ? (
        <p className="rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
          Noch nicht verifiziert. Du kannst buchen – QA zählt das als Verstoß.
        </p>
      ) : null}
      {ACTION_GROUPS.map((group) => (
        <div key={group.title}>
          <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
            {group.title}
          </p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {group.items.map((item) => (
              <Button
                key={item}
                variant="outline"
                className="h-auto justify-start whitespace-normal px-3 py-2"
                onClick={() => onAction(item)}
              >
                {actionLabel(item)}
              </Button>
            ))}
          </div>
        </div>
      ))}
      {actions.length > 0 ? (
        <div>
          <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
            Gebucht in diesem Call
          </p>
          <ul className="space-y-1 text-xs">
            {actions.map((action) => (
              <li key={action.id} className="rounded bg-muted px-2 py-1">
                {action.label}
                {action.detail ? ` · ${action.detail}` : ""}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  )
}

function KnowledgePane({
  ids,
  opened,
  onOpen,
}: {
  ids: string[]
  opened: string[]
  onOpen: (id: string) => void
}) {
  const articles = KNOWLEDGE.filter((article) => ids.includes(article.id))
  return (
    <div className="space-y-3">
      {articles.map((article) => {
        const isOpen = opened.includes(article.id)
        return (
          <article key={article.id} className="rounded-lg border p-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-medium">{article.title}</p>
                <p className="text-xs text-muted-foreground">{article.category}</p>
              </div>
              <Button size="sm" variant="outline" onClick={() => onOpen(article.id)}>
                {isOpen ? "Gelesen" : "Öffnen"}
              </Button>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{article.summary}</p>
            {isOpen ? (
              <p className="mt-2 text-sm leading-6">{article.body}</p>
            ) : null}
          </article>
        )
      })}
    </div>
  )
}

function statusLabel(status: Order["status"]) {
  switch (status) {
    case "processing":
      return "In Bearbeitung"
    case "shipped":
      return "Unterwegs"
    case "delivered":
      return "Zugestellt"
    case "returned":
      return "Retourniert"
    case "cancelled":
      return "Storniert"
    case "lost":
      return "Verlust"
  }
}
