"use client"

import { Button } from "@/components/ui/button"
import { ACHIEVEMENTS, rankForXp } from "@/lib/ranks"
import type { CallRecord, Career } from "@/lib/types"
import { Sparkles } from "lucide-react"

type Props = {
  records: CallRecord[]
  before: Career
  after: Career
  newAchievements: string[]
  onLobby: () => void
}

export function ShiftDebrief({
  records,
  before,
  after,
  newAchievements,
  onLobby,
}: Props) {
  const avgCsat =
    records.reduce((sum, record) => sum + record.score.csat, 0) / records.length
  const avgQa =
    records.reduce((sum, record) => sum + record.score.overall, 0) / records.length
  const xpGained = after.xp - before.xp
  const rankBefore = rankForXp(before.xp)
  const rankAfter = rankForXp(after.xp)
  const promoted = rankBefore.id !== rankAfter.id

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-10">
      <div>
        <p className="text-xs tracking-widest text-primary uppercase">
          Schichtende
        </p>
        <h2 className="font-heading mt-1 text-3xl font-semibold">
          Headset ab, Zahlen an.
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          {promoted
            ? `Beförderung: ${rankBefore.title} → ${rankAfter.title}.`
            : `Rang bleibt ${rankAfter.title}. XP lügt nicht.`}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Mini label="Ø CSAT" value={avgCsat.toFixed(2)} />
        <Mini label="Ø QA" value={String(Math.round(avgQa))} />
        <Mini label="XP" value={`+${xpGained}`} />
      </div>

      <div className="overflow-hidden rounded-xl ring-1 ring-foreground/10">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-2 font-medium">Call</th>
              <th className="px-3 py-2 font-medium">CSAT</th>
              <th className="px-3 py-2 font-medium">QA</th>
              <th className="px-3 py-2 font-medium">XP</th>
            </tr>
          </thead>
          <tbody>
            {records.map((record) => (
              <tr key={record.caseId} className="border-t">
                <td className="px-3 py-2">{record.title}</td>
                <td className="px-3 py-2 tabular-nums">
                  {record.score.csat.toFixed(1)}
                </td>
                <td className="px-3 py-2 tabular-nums">{record.score.overall}</td>
                <td className="px-3 py-2 tabular-nums">+{record.score.xp}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {newAchievements.length > 0 ? (
        <div className="space-y-2">
          <p className="text-sm font-medium">Neu freigeschaltet</p>
          {newAchievements.map((id) => {
            const item = ACHIEVEMENTS.find((entry) => entry.id === id)
            if (!item) return null
            return (
              <div
                key={id}
                className="flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-sm"
              >
                <Sparkles className="size-4 text-primary" />
                <span>
                  <strong>{item.title}.</strong> {item.description}
                </span>
              </div>
            )
          })}
        </div>
      ) : null}

      <Button size="lg" onClick={onLobby}>
        Zurück in die Lobby
      </Button>
    </div>
  )
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card p-4 text-center ring-1 ring-foreground/10">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-xl font-semibold">{value}</p>
    </div>
  )
}
