import type { CaseDefinition, Customer, Order } from "./types"

const thorsten: Customer = {
  id: "cust-thorsten",
  name: "Thorsten Berger",
  email: "t.berger.hh@mailbox.de",
  phone: "+49 176 8821 4409",
  address: "Lerchenfeld 12",
  postcode: "22081",
  city: "Hamburg",
  memberSince: "2019-03-12",
  prime: true,
  ordersCount: 84,
  returnRate: "niedrig",
  csatHistory: 4.7,
  flags: ["Prime", "treu"],
  accountNotes: ["2014: einmal Porch-Pirate, Ersatz genehmigt"],
}

const yasmin: Customer = {
  id: "cust-yasmin",
  name: "Yasmin El-Sayed",
  email: "yasmin.elsayed@posteo.de",
  phone: "+49 157 3044 1182",
  address: "Sonnenallee 201",
  postcode: "12059",
  city: "Berlin",
  memberSince: "2021-11-02",
  prime: true,
  ordersCount: 41,
  returnRate: "mittel",
  csatHistory: 4.2,
  flags: ["Prime"],
  accountNotes: [],
}

const hildegard: Customer = {
  id: "cust-hild",
  name: "Hildegard Köhler",
  email: "h.koehler@t-online.de",
  phone: "+49 221 9733 140",
  address: "Ursulaplatz 4",
  postcode: "50668",
  city: "Köln",
  memberSince: "2016-08-20",
  prime: false,
  ordersCount: 19,
  returnRate: "niedrig",
  csatHistory: 4.9,
  flags: ["Senior", "braucht Geduld"],
  accountNotes: ["Bevorzugt klare, langsame Erklärungen. Kein Fachjargon."],
}

const kevin: Customer = {
  id: "cust-kevin",
  name: "Kevin Brandt",
  email: "kevin.brandtt@gmail.com",
  phone: "+49 163 2290 771",
  address: "Karlstraße 88",
  postcode: "80335",
  city: "München",
  memberSince: "2025-12-01",
  prime: false,
  ordersCount: 7,
  returnRate: "hoch",
  csatHistory: 2.1,
  flags: ["hohe Retouren", "Serial-Alert"],
  accountNotes: [
    "Return-Foto 03.10.2026: leere Umverpackung, Siegel aufgerissen.",
    "Serial ECH-2291 bereits am 04.10. in Leipzig aktiviert.",
  ],
}

const henrik: Customer = {
  id: "cust-henrik",
  name: "Dr. Henrik Meier",
  email: "henrik.meier@kanzlei-meier.de",
  phone: "+49 69 2471 903",
  address: "Goethestraße 26",
  postcode: "60313",
  city: "Frankfurt am Main",
  memberSince: "2018-01-09",
  prime: true,
  ordersCount: 210,
  returnRate: "niedrig",
  csatHistory: 4.4,
  flags: ["Prime", "VIP-Umsatz"],
  accountNotes: ["Prime jährlich seit 2018, letzte Verlängerung 12.04.2026, 69,00 €"],
}

const luca: Customer = {
  id: "cust-luca",
  name: "Luca Hoffmann",
  email: "luca.hoffmann@web.de",
  phone: "+49 151 6442 0901",
  address: "Königsstraße 15",
  postcode: "70173",
  city: "Stuttgart",
  memberSince: "2022-06-14",
  prime: true,
  ordersCount: 33,
  returnRate: "niedrig",
  csatHistory: 4.5,
  flags: ["Prime"],
  accountNotes: [],
}

const nina: Customer = {
  id: "cust-nina",
  name: "Nina Krüger",
  email: "nina.krueger@icloud.com",
  phone: "+49 179 5501 226",
  address: "Holstenstraße 48",
  postcode: "22767",
  city: "Hamburg",
  memberSince: "2020-02-02",
  prime: true,
  ordersCount: 12,
  returnRate: "niedrig",
  csatHistory: 4.8,
  flags: ["Prime", "Empfängerin, nicht Zahlerin"],
  accountNotes: [
    "Konto existiert, aber die Geschenkbestellung liegt auf dem Konto von Mara Krüger.",
  ],
}

const mara: Customer = {
  id: "cust-mara",
  name: "Mara Krüger",
  email: "mara.k@mailbox.org",
  phone: "+49 40 8891 332",
  address: "Schulterblatt 9",
  postcode: "20357",
  city: "Hamburg",
  memberSince: "2017-09-01",
  prime: true,
  ordersCount: 56,
  returnRate: "niedrig",
  csatHistory: 4.6,
  flags: ["Prime", "Schenkende"],
  accountNotes: ["Geschenkbestellung an Nina Krüger, Holstenstraße 48."],
}

const anna: Customer = {
  id: "cust-anna",
  name: "Anna Müller",
  email: "anna.mueller.koeln@gmail.com",
  phone: "+49 221 441 8829",
  address: "Ehrenstraße 71",
  postcode: "50672",
  city: "Köln",
  memberSince: "2023-04-18",
  prime: true,
  ordersCount: 22,
  returnRate: "niedrig",
  csatHistory: 4.6,
  flags: ["Prime"],
  accountNotes: [],
}

const annalena: Customer = {
  id: "cust-annalena",
  name: "Anna-Lena Müller",
  email: "annalena.mueller@outlook.de",
  phone: "+49 211 990 4410",
  address: "Oststraße 12",
  postcode: "40211",
  city: "Düsseldorf",
  memberSince: "2024-01-11",
  prime: false,
  ordersCount: 5,
  returnRate: "mittel",
  csatHistory: 3.9,
  flags: [],
  accountNotes: ["Anderes Konto, ähnliche Schreibweise. Nicht verwechseln."],
}

const orderAirfryer: Order = {
  id: "306-7482910-2214758",
  customerId: "cust-thorsten",
  placedAt: "2026-10-18T09:12:00",
  status: "delivered",
  total: 79.99,
  shippingAddress: "Lerchenfeld 12, 22081 Hamburg",
  returnWindowEnds: "2026-11-20",
  items: [
    {
      id: "item-air",
      name: "RiverBasics Heißluftfritteuse 4,5 l",
      asin: "B0RIVERAIR",
      qty: 1,
      price: 79.99,
      hue: 28,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-10-18T16:40:00", location: "Leipzig Hub", status: "Sendung übernommen" },
    { at: "2026-10-19T04:10:00", location: "Hamburg Zustellbasis", status: "In Zustellung" },
    {
      at: "2026-10-19T11:42:00",
      location: "Hamburg 22081",
      status: "Zugestellt",
      note: "Abgelegt in der Packstation? Eintrag: „Briefkasten/Haustür“. Kein Foto.",
    },
  ],
}

const orderSpatulaMixup: Order = {
  id: "306-1192033-8841207",
  customerId: "cust-yasmin",
  placedAt: "2026-10-20T19:05:00",
  status: "delivered",
  total: 129.0,
  shippingAddress: "Sonnenallee 201, 12059 Berlin",
  returnWindowEnds: "2026-11-22",
  items: [
    {
      id: "item-glow",
      name: "FireGlow Stick – LED-Lampe, 2er-Set",
      asin: "B0FIREGLOW",
      qty: 1,
      price: 129.0,
      hue: 42,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-10-21T08:00:00", location: "Poznań", status: "Versendet" },
    {
      at: "2026-10-22T14:18:00",
      location: "Berlin 12059",
      status: "Zugestellt",
      note: "Foto: kleiner Umschlag, nicht die Lampenbox.",
    },
  ],
}

const orderKettle: Order = {
  id: "302-5518290-1003341",
  customerId: "cust-hild",
  placedAt: "2026-10-21T11:30:00",
  status: "shipped",
  total: 34.99,
  shippingAddress: "Ursulaplatz 4, 50668 Köln",
  returnWindowEnds: "2026-11-24",
  items: [
    {
      id: "item-kettle",
      name: "RiverBasics Wasserkocher 1,7 l, Edelstahl",
      asin: "B0KETTLE17",
      qty: 1,
      price: 34.99,
      hue: 210,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-10-21T18:12:00", location: "Rheinberg", status: "Sendung unterwegs" },
    {
      at: "2026-10-23T07:40:00",
      location: "Köln Zustellbasis",
      status: "In Zustellung",
      note: "Zustellung heute, Zeitfenster 11–14 Uhr.",
    },
  ],
}

const orderEcho: Order = {
  id: "306-9001882-4410299",
  customerId: "cust-kevin",
  placedAt: "2026-09-28T21:44:00",
  status: "returned",
  total: 99.99,
  shippingAddress: "Karlstraße 88, 80335 München",
  returnWindowEnds: "2026-10-30",
  items: [
    {
      id: "item-echo",
      name: "EchoSphere Mini (2026)",
      asin: "B0ECHOMINI",
      qty: 1,
      price: 99.99,
      hue: 190,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-09-30T12:00:00", location: "München", status: "Zugestellt" },
    {
      at: "2026-10-03T09:12:00",
      location: "Returns Center Graben",
      status: "Rücksendung eingegangen",
      note: "Gewicht 180 g (erwartet 720 g). Foto: leere Box, Inlay fehlt. Serial ECH-2291 fremdaktiviert.",
    },
  ],
}

const orderBlender: Order = {
  id: "305-4412290-7730192",
  customerId: "cust-luca",
  placedAt: "2026-10-12T08:22:00",
  status: "delivered",
  total: 89.0,
  shippingAddress: "Königsstraße 15, 70173 Stuttgart",
  returnWindowEnds: "2026-11-14",
  items: [
    {
      id: "item-blend",
      name: "TurboMix Standmixer 1200 W",
      asin: "B0TURBOMIX",
      qty: 1,
      price: 89.0,
      hue: 12,
      seller: "ElektroBlitz GmbH",
      fulfilledBy: "Marketplace",
    },
  ],
  tracking: [
    { at: "2026-10-13T10:00:00", location: "Seller-Lager Essen", status: "Versendet" },
    { at: "2026-10-16T16:45:00", location: "Stuttgart", status: "Zugestellt" },
  ],
}

const orderGift: Order = {
  id: "306-2201884-9910021",
  customerId: "cust-mara",
  placedAt: "2026-10-15T20:01:00",
  status: "delivered",
  total: 249.0,
  shippingAddress: "Holstenstraße 48, 22767 Hamburg",
  returnWindowEnds: "2026-11-18",
  isGift: true,
  giftMessage: "Alles Liebe zum Umzug – Mara",
  items: [
    {
      id: "item-kindle",
      name: "KindleLight Paper (16 GB)",
      asin: "B0KINDLEP",
      qty: 1,
      price: 249.0,
      hue: 55,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-10-17T13:20:00", location: "Hamburg", status: "Zugestellt", note: "Geschenkverpackung." },
  ],
}

const orderLitterA: Order = {
  id: "306-3310021-1188290",
  customerId: "cust-anna",
  placedAt: "2026-10-08T06:00:00",
  status: "delivered",
  total: 22.9,
  shippingAddress: "Ehrenstraße 71, 50672 Köln",
  returnWindowEnds: "2026-11-10",
  subscription: true,
  items: [
    {
      id: "item-litter-a",
      name: "RiverBasics Klumpstreu 12 kg, unparfümiert",
      asin: "B0CATLIT12",
      qty: 1,
      price: 22.9,
      hue: 80,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-10-09T12:00:00", location: "Köln", status: "Zugestellt" },
  ],
}

const orderLitterB: Order = {
  id: "306-3310021-1188299",
  customerId: "cust-anna",
  placedAt: "2026-10-08T06:00:12",
  status: "delivered",
  total: 22.9,
  shippingAddress: "Ehrenstraße 71, 50672 Köln",
  returnWindowEnds: "2026-11-10",
  subscription: true,
  items: [
    {
      id: "item-litter-b",
      name: "RiverBasics Klumpstreu 12 kg, unparfümiert",
      asin: "B0CATLIT12",
      qty: 1,
      price: 22.9,
      hue: 80,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-10-09T12:08:00", location: "Köln", status: "Zugestellt", note: "Zweite Tour, gleiches Abo." },
  ],
}

const orderAnnalena: Order = {
  id: "302-8801142-0093318",
  customerId: "cust-annalena",
  placedAt: "2026-10-02T15:11:00",
  status: "delivered",
  total: 14.99,
  shippingAddress: "Oststraße 12, 40211 Düsseldorf",
  returnWindowEnds: "2026-11-04",
  items: [
    {
      id: "item-usb",
      name: "USB-C Kabel 2 m",
      asin: "B0USBCABLE",
      qty: 2,
      price: 7.49,
      hue: 200,
      seller: "Amazon.de",
      fulfilledBy: "Amazon",
    },
  ],
  tracking: [
    { at: "2026-10-03T10:00:00", location: "Düsseldorf", status: "Zugestellt" },
  ],
}

function baseCase(
  rest: Omit<CaseDefinition, "dialogue"> & { dialogue?: CaseDefinition["dialogue"] }
): CaseDefinition {
  return {
    ...rest,
    dialogue: rest.dialogue ?? [],
  }
}

export const CASES: CaseDefinition[] = [
  baseCase({
    id: "oma-tracking",
    title: "Der verschwundene Wasserkocher",
    blurb: "Eine höfliche Anruferin glaubt, sie sei betrogen worden. Tracking lesen, erklären, nicht erstatten.",
    queue: "Retail",
    difficulty: 1,
    timeLimitSec: 360,
    personality: "sweet",
    callerId: "+49 221 9733 140",
    primaryCustomerId: "cust-hild",
    directory: [hildegard],
    orders: [orderKettle],
    knowledgeIds: ["identity", "delivered-missing"],
    opening: [
      "Ach, guten Tag… ich wollte nur fragen, ob das mit dem Wasserkocher überhaupt stimmt.",
      "Da steht in der App irgendwas auf Englisch und mein Nachbar sagt, das sei Betrug.",
    ],
    identity: {
      required: true,
      hint: "Name und PLZ 50668 oder Bestellung 302-5518290-1003341.",
    },
    solution: {
      requiredActions: ["resend_tracking", "education_only"],
      optionalActions: ["goodwill"],
      forbiddenActions: ["refund_full", "replacement", "escalate_fraud"],
      requiredViews: ["customer", "order", "tracking"],
      mustOpenOrderIds: ["302-5518290-1003341"],
      mustOpenTrackingIds: ["302-5518290-1003341"],
      mustReadKnowledgeIds: [],
      mustVerify: true,
      mustNote: true,
      wrapUp: "education",
    },
    actionBeats: {
      resend_tracking: {
        customerLine: "Ach, eine E-Mail kommt? Dann schaue ich mit meiner Nichte später rein. Das beruhigt mich.",
        moodDelta: 12,
      },
      education_only: {
        customerLine: "Also kommt er heute noch. Gut. Dann warte ich. Sie erklären das viel netter als die App.",
        moodDelta: 16,
      },
      refund_full: {
        customerLine: "Eine Erstattung? Aber ich wollte den Kocher doch noch… na gut, wenn Sie meinen.",
        moodDelta: 8,
      },
    },
    coaching: {
      perfect: "Geduld, Tracking gelesen, nichts erfunden. Genau so sieht Retail-CRM aus.",
      good: "Sie ist beruhigt. Ein bisschen mehr Systemarbeit und QA nickt.",
      fail: "Du hast ein Versandthema mit Geld zugeschüttet oder das Tracking nicht gelesen.",
      misses: {
        views: "Die Sendung ist „in Zustellung“, Zeitfenster 11–14 Uhr. Das steht nur im Tracking.",
        actions: "Tracking-Mail plus klare Erklärung reichen. Kein Ersatz, keine Erstattung.",
        forbidden: "Sie wollte Sicherheit, kein Geld. Unnötige Erstattung ist teuer und falsch.",
        empathy: "Langsamer sprechen, Fachwörter übersetzen. Hildegard ist kein Ticket.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "h1",
            text: "Guten Tag, Frau Köhler – ich schaue das in Ruhe mit Ihnen an.",
            tone: "empathy",
            moodDelta: 10,
            customerReply: "Oh, wie nett. Ich heiße wirklich Köhler. Der Kocher sollte heute kommen.",
            nextNodeId: "ask",
          },
          {
            id: "h2",
            text: "Bestellnummer bitte, ich habe wenig Zeit.",
            tone: "cold",
            moodDelta: -14,
            customerReply: "Entschuldigung… ich finde die Nummer nicht, die ist so lang…",
            nextNodeId: "ask",
          },
          {
            id: "h3",
            text: "Das ist kein Betrug. Haben Sie Ihre Postleitzahl zur Hand?",
            tone: "probe",
            moodDelta: 6,
            customerReply: "50668, Köln. Ursulaplatz. Kommt der Mann heute noch?",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "h4",
            text: "Ich prüfe die Sendung im System. Einen kleinen Moment.",
            tone: "hold",
            moodDelta: 4,
            customerReply: "Ja gerne. Ich warte, ich habe Zeit.",
            nextNodeId: "wait",
          },
          {
            id: "h5",
            text: "Vermutlich geklaut, ich löse sofort Ersatz aus.",
            tone: "cold",
            moodDelta: 2,
            customerReply: "Geklaut? Oh je. Der Nachbar hat doch gesagt, das Internet ist gefährlich.",
            nextNodeId: "wait",
          },
          {
            id: "h6",
            text: "Die App zeigt nur den Status. Ich erkläre ihn Ihnen gleich anhand der Sendung.",
            tone: "empathy",
            moodDelta: 8,
            customerReply: "Das wäre lieb. Englisch kann ich nicht so gut.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "h7",
            text: "Er ist unterwegs, Zustellung heute 11–14 Uhr. Kein Betrug.",
            tone: "empathy",
            moodDelta: 10,
            customerReply: "Heute noch? Dann stelle ich den Türkeil raus. Danke, junges.",
            nextNodeId: "close",
          },
          {
            id: "h8",
            text: "Ich kann Ihnen 34,99 € erstatten, dann ist Ruhe.",
            tone: "cold",
            moodDelta: 0,
            customerReply: "Aber dann habe ich keinen Kocher… ich wollte doch nur wissen, ob er kommt.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
  baseCase({
    id: "wrong-item",
    title: "Lampe bestellt, Pfannenwender bekommen",
    blurb: "Inhalt ≠ Bestellung. Ersatz plus Rücksendeetikett, nicht beides voll erstatten.",
    queue: "Retail",
    difficulty: 1,
    timeLimitSec: 330,
    personality: "chatty",
    callerId: "+49 157 3044 1182",
    primaryCustomerId: "cust-yasmin",
    directory: [yasmin],
    orders: [orderSpatulaMixup],
    knowledgeIds: ["identity", "wrong-item"],
    opening: [
      "Hi. Also. Ich habe FireGlow Sticks bestellt.",
      "Im Karton war ein einzelner Pfannenwender. Pink. Ich koche nicht mal.",
    ],
    identity: {
      required: true,
      hint: "E-Mail yasmin.elsayed@posteo.de oder Bestellung 306-1192033-8841207.",
    },
    solution: {
      requiredActions: ["replacement", "return_label"],
      optionalActions: ["goodwill"],
      forbiddenActions: ["refund_full", "escalate_fraud"],
      requiredViews: ["customer", "order"],
      mustOpenOrderIds: ["306-1192033-8841207"],
      mustOpenTrackingIds: ["306-1192033-8841207"],
      mustReadKnowledgeIds: ["wrong-item"],
      mustVerify: true,
      mustNote: true,
      wrapUp: "replacement",
    },
    actionBeats: {
      replacement: {
        customerLine: "Okay, neue Lampen. Solange kein zweiter Pfannenwender kommt.",
        moodDelta: 14,
      },
      return_label: {
        customerLine: "Rücksendeetikett ist fair. Den Wender schicke ich zurück, versprochen – auch wenn er irgendwie… persönlichkeit hat.",
        moodDelta: 8,
      },
      refund_full: {
        customerLine: "Geld zurück und Lampen? Ich sag nicht nein, eure Buchhaltung vielleicht schon.",
        moodDelta: 10,
      },
    },
    coaching: {
      perfect: "Klassiker sauber gelöst: Ersatz, Etikett, Wissen gelesen, Ton locker aber präzise.",
      good: "Richtige Richtung. QA will Ersatz plus Retourenweg, nicht nur Entschuldigung.",
      fail: "Falscher Artikel ist kein Betrugsfall und kein Anlass für Vollrefund plus Extra-Chaos.",
      misses: {
        knowledge: "Im Wissenstab steht: Ersatz + Etikett, keine doppelte Entschädigung.",
        actions: "Ohne Ersatz bleibt sie im Dunkeln. Ohne Etikett bleibt der Wender in Berlin.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "y1",
            text: "Das klingt nach einer wilden Packnacht. Ich prüfe die Bestellung.",
            tone: "empathy",
            moodDelta: 10,
            customerReply: "Danke. Foto habe ich, falls ihr Spaß an Küchenutensilien habt.",
            nextNodeId: "ask",
          },
          {
            id: "y2",
            text: "Sind Sie sicher, dass Sie nicht den Wender bestellt haben?",
            tone: "cold",
            moodDelta: -16,
            customerReply: "Ganz sicher. Ich wollte Ambiente, kein Omelett.",
            nextNodeId: "ask",
          },
          {
            id: "y3",
            text: "E-Mail-Adresse zur Bestätigung, dann lege ich den Fall an.",
            tone: "probe",
            moodDelta: 6,
            customerReply: "yasmin.elsayed@posteo.de – mit y, nicht mit j.",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "y4",
            text: "Ich löse Ersatz aus und schicke ein Rücksendeetikett für den Wender.",
            tone: "neutral",
            moodDelta: 8,
            customerReply: "Perfekt. Hauptsache die Lampen kommen, ich habe Gäste am Freitag.",
            nextNodeId: "wait",
          },
          {
            id: "y5",
            text: "Behalten Sie den Wender, ich erstatte alles und gut ist.",
            tone: "cold",
            moodDelta: 4,
            customerReply: "Ich will die Lampen. Den Wender wirklich nicht.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "y6",
            text: "Ersatz geht raus, Express. Sorry für den Küchen-Surprise.",
            tone: "empathy",
            moodDelta: 8,
            customerReply: "Passiert. Solange ihr das System nicht mit Pfannenwendern trainiert.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
  baseCase({
    id: "porch-pirate",
    title: "Zugestellt, Briefkasten leer",
    blurb: "Tracking sagt zugestellt, kein Foto. Einmal Kulanz, Konto ist sauber.",
    queue: "Retail",
    difficulty: 2,
    timeLimitSec: 360,
    personality: "angry",
    callerId: "+49 176 8821 4409",
    primaryCustomerId: "cust-thorsten",
    directory: [thorsten],
    orders: [orderAirfryer],
    knowledgeIds: ["identity", "delivered-missing", "goodwill"],
    opening: [
      "Ja hallo, euer Bote spinnt.",
      "Fritteuse sollte Samstag da sein, Status zugestellt, vor der Tür: gar nichts. Ich war den ganzen Tag Homeoffice!",
    ],
    identity: {
      required: true,
      hint: "Telefon endet auf 4409 oder Bestellung 306-7482910-2214758.",
    },
    solution: {
      requiredActions: ["replacement"],
      optionalActions: ["goodwill", "resend_tracking"],
      forbiddenActions: ["refuse", "escalate_fraud", "refund_full"],
      requiredViews: ["customer", "order", "tracking"],
      mustOpenOrderIds: ["306-7482910-2214758"],
      mustOpenTrackingIds: ["306-7482910-2214758"],
      mustReadKnowledgeIds: ["delivered-missing"],
      mustVerify: true,
      mustNote: true,
      wrapUp: "replacement",
    },
    actionBeats: {
      replacement: {
        customerLine: "Okay. Neue Fritteuse. Diesmal bitte nicht in den Paralleluniversum-Briefkasten.",
        moodDelta: 18,
      },
      goodwill: {
        customerLine: "Kleine Gutschrift? Naja. Bringt die Fritten nicht, ist aber anständig.",
        moodDelta: 6,
      },
      refuse: {
        customerLine: "SIE GLAUBEN MIR NICHT? Ich soll die Luft frittieren oder was?",
        moodDelta: -30,
      },
    },
    coaching: {
      perfect: "Wut abgeholt, Tracking geprüft, einmal Ersatz. So hält man Prime-Kunden.",
      good: "Er ist ruhiger. QA achtet darauf, dass du nicht ablehnst und nicht doppelst.",
      fail: "Entweder hast du ihn als Lügner behandelt oder das Konto mit Geld zugeschüttet.",
      misses: {
        views: "Ohne Tracking siehst du: kein Foto, Eintrag Briefkasten. Genau deshalb ist Kulanz okay.",
        forbidden: "Ablehnen bei sauberem Konto + fehlendem Foto ist der schnellste Weg zu einer Beschwerde.",
        empathy: "Erst anerkennen, dann System. Reine Policy-Floskeln heizen ihn an.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "t1",
            text: "Das ist richtig ärgerlich – ich prüfe Sendung und Konto sofort.",
            tone: "empathy",
            moodDelta: 12,
            customerReply: "Bitte. Ich will keine Floskeln, ich will die Fritteuse.",
            nextNodeId: "ask",
          },
          {
            id: "t2",
            text: "Zugestellt heißt zugestellt. Haben Sie hinter den Mülltonnen geguckt?",
            tone: "cold",
            moodDelta: -22,
            customerReply: "Hören Sie mal. Ich bin nicht blöd. Da war nichts.",
            nextNodeId: "ask",
          },
          {
            id: "t3",
            text: "Zur Sicherheit: die Bestellnummer endet auf 2214758, richtig?",
            tone: "probe",
            moodDelta: 4,
            customerReply: "Ja, 306-7482910-2214758. RiverBasics Fritteuse.",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "t4",
            text: "Kein Zustellfoto, Konto unauffällig – ich löse eine Ersatzlieferung aus.",
            tone: "neutral",
            moodDelta: 10,
            customerReply: "Gut. Und schreibt dem Boten Bescheid, dass „Briefkasten“ kein Zauberspruch ist.",
            nextNodeId: "wait",
          },
          {
            id: "t5",
            text: "Das müssen wir als Betrugsverdacht markieren.",
            tone: "cold",
            moodDelta: -18,
            customerReply: "Betrug? ICH rufe euch an! Unglaublich.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "t6",
            text: "Ersatz ist raus. Sorry für den Homeoffice-Samstag ohne Fritten.",
            tone: "empathy",
            moodDelta: 8,
            customerReply: "Passt. Danke, dass Sie nicht so ein Skript runterleiern.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
  baseCase({
    id: "name-collision",
    title: "Welche Anna Müller?",
    blurb: "Suche nach Namen trifft zwei Konten. Nur die Kölnerin mit dem Abo ist die Anruferin.",
    queue: "Abos",
    difficulty: 2,
    timeLimitSec: 390,
    personality: "polite",
    callerId: "+49 221 441 8829",
    primaryCustomerId: "cust-anna",
    directory: [anna, annalena],
    orders: [orderLitterA, orderLitterB, orderAnnalena],
    knowledgeIds: ["identity", "sns"],
    opening: [
      "Hallo, Anna Müller hier. Ich habe zweimal dasselbe Katzenstreu bekommen.",
      "Einmal reicht, die Katzen sind nicht im Krafttraining.",
    ],
    identity: {
      required: true,
      hint: "Nicht den Namen allein suchen. E-Mail, Telefon 8829 oder PLZ 50672.",
    },
    solution: {
      requiredActions: ["refund_full", "pause_subscription"],
      optionalActions: ["return_label"],
      forbiddenActions: ["replacement", "escalate_fraud"],
      requiredViews: ["customer", "orders"],
      mustOpenOrderIds: ["306-3310021-1188299"],
      mustOpenTrackingIds: [],
      mustReadKnowledgeIds: ["sns"],
      mustVerify: true,
      mustNote: true,
      wrapUp: "subscription",
    },
    actionBeats: {
      refund_full: {
        customerLine: "Danke, eine der beiden Lieferungen könnt ihr zurückbuchen.",
        moodDelta: 12,
      },
      pause_subscription: {
        customerLine: "Pause ist gut. Kündigen muss nicht, die Tiere essen das Zeug ja irgendwann.",
        moodDelta: 10,
      },
    },
    coaching: {
      perfect: "Namenskollision erkannt, richtiges Konto, Dublette erstattet, Abo pausiert.",
      good: "Du warst nah dran. Wichtig ist: Düsseldorf ist die falsche Anna.",
      fail: "Du hast entweder das falsche Konto angefasst oder das Abo-Thema nicht gelöst.",
      misses: {
        verify: "„Anna Müller“ ist keine Identität. E-Mail oder PLZ trennt Köln von Düsseldorf.",
        actions: "Nur die Dublette erstatten und Subscribe & Save pausieren.",
        views: "Zwei Bestellungen am selben Morgen – das siehst du nur in der Auftragsliste.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "a1",
            text: "Zwei Säcke Streu, ein Abo – das klingt nach einem Systemdoppler. Ich suche Ihr Konto.",
            tone: "empathy",
            moodDelta: 8,
            customerReply: "Genau. Ich wohne in Köln, Ehrenstraße. Nicht Düsseldorf, falls das im Weg steht.",
            nextNodeId: "ask",
          },
          {
            id: "a2",
            text: "Ich öffne das erste Müller-Konto, das ich finde.",
            tone: "cold",
            moodDelta: -8,
            customerReply: "Vorsicht, den Namen hat halb Deutschland. Ich bin die aus Köln.",
            nextNodeId: "ask",
          },
          {
            id: "a3",
            text: "Zur Sicherheit: PLZ 50672 und die Mail mit gmail, richtig?",
            tone: "probe",
            moodDelta: 10,
            customerReply: "Ja. anna.mueller.koeln@gmail.com. Die andere Anna kenne ich nicht.",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "a4",
            text: "Ich erstatte die zweite Lieferung und setze das Abo auf Pause.",
            tone: "neutral",
            moodDelta: 8,
            customerReply: "Super. Die Katzen danken Ihnen. Also, metaphorisch.",
            nextNodeId: "wait",
          },
          {
            id: "a5",
            text: "Ich schicke noch eine dritte, dann haben Sie Vorrat.",
            tone: "cold",
            moodDelta: -12,
            customerReply: "Bitte nicht. Mein Flur ist kein Lager.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "a6",
            text: "Erstattung der Dublette ist raus, Abo pausiert. Schönen Abend an die Katzen.",
            tone: "empathy",
            moodDelta: 6,
            customerReply: "Mache ich. Danke fürs genaue Hinsehen.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
  baseCase({
    id: "prime-cancel",
    title: "Die 69-Euro-Diskussion",
    blurb: "Jahres-Prime nach acht Monaten. Kündigen ja, volle Rückzahlung nein. Retention versuchen.",
    queue: "Prime",
    difficulty: 2,
    timeLimitSec: 360,
    personality: "legal",
    callerId: "+49 69 2471 903",
    primaryCustomerId: "cust-henrik",
    directory: [henrik],
    orders: [],
    knowledgeIds: ["identity", "prime-cancel"],
    opening: [
      "Meier, guten Tag. Ich kündige Prime und erwarte die vollständige Erstattung der 69 Euro.",
      "Ich habe in diesem Jahr kaum bestellt. Das ist Verbrauchertäuschung.",
    ],
    identity: {
      required: true,
      hint: "Kanzlei-Mail oder Telefon endet auf 0903.",
    },
    solution: {
      requiredActions: ["prime_retention", "refuse"],
      optionalActions: ["goodwill"],
      forbiddenActions: ["refund_full"],
      requiredViews: ["customer", "knowledge"],
      mustOpenOrderIds: [],
      mustOpenTrackingIds: [],
      mustReadKnowledgeIds: ["prime-cancel"],
      mustVerify: true,
      mustNote: true,
      wrapUp: "retention",
    },
    actionBeats: {
      prime_retention: {
        customerLine: "Vorteile. Hm. Versand habe ich schon genutzt, das stimmt.",
        moodDelta: 4,
      },
      refuse: {
        customerLine: "Also keine 69 Euro zurück. Notiert. Dann kündigen Sie wenigstens korrekt.",
        moodDelta: -4,
      },
      refund_full: {
        customerLine: "Sehen Sie, es geht doch. Ich erwarte die Buchung heute.",
        moodDelta: 14,
      },
      goodwill: {
        customerLine: "Zehn Euro Gutschrift ist kein Anerkenntnis, aber ich akzeptiere den Gestus.",
        moodDelta: 6,
      },
    },
    coaching: {
      perfect: "Policy gehalten, höflich geblieben, Retention versucht. Anwälte mögen Klarheit.",
      good: "Keine Vollerstattung ist schon die halbe Miete. Retention und Wissenstab machen es rund.",
      fail: "69 € zurück nach acht Monaten ist der Klassiker, den QA rausfisht.",
      misses: {
        knowledge: "Im Prime-Artikel: nach der Mindestnutzung keine volle Jahresrückzahlung.",
        forbidden: "Du hast die Jahresgebühr voll erstattet. Das ist ein direkter Policy-Treffer.",
        actions: "Retention-Angebot plus klare Ablehnung der Vollerstattung.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "p1",
            text: "Ich schaue mir Laufzeit und Richtlinie an und erkläre Ihnen die Optionen klar.",
            tone: "neutral",
            moodDelta: 4,
            customerReply: "Bitte ohne Marketing. Fakten.",
            nextNodeId: "ask",
          },
          {
            id: "p2",
            text: "Kein Problem, volle 69 Euro, sofort.",
            tone: "cold",
            moodDelta: 8,
            customerReply: "Endlich jemand mit Entscheidungsbefugnis.",
            nextNodeId: "ask",
          },
          {
            id: "p3",
            text: "Zur Verifizierung: Sie erreichen uns aus der Kanzlei-Nummer, Mail henrik.meier@kanzlei-meier.de?",
            tone: "probe",
            moodDelta: 2,
            customerReply: "Korrekt. Dr. Henrik Meier.",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "p4",
            text: "Verlängerung war im April. Volle Rückzahlung ist nach acht Monaten nicht vorgesehen. Kündigung zum Laufzeitende plus Vorteile kurz nennen?",
            tone: "probe",
            moodDelta: 0,
            customerReply: "Nennen Sie die Vorteile. Kurz.",
            nextNodeId: "wait",
          },
          {
            id: "p5",
            text: "Wenn Sie drohen, erstatt ich lieber alles.",
            tone: "cold",
            moodDelta: 6,
            customerReply: "Das wäre vernünftig.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "p6",
            text: "Gratis-Versand, Prime Video, Schnelllieferung – und Kündigung ohne volle Rückzahlung. Ich dokumentiere das.",
            tone: "neutral",
            moodDelta: 2,
            customerReply: "Verstanden. Dann belasse ich Prime bis April und prüfe intern. Guten Tag.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
  baseCase({
    id: "marketplace",
    title: "Der Mixer vom Dritten",
    blurb: "Verkäufer ElektroBlitz, nicht Amazon. Keine Amazon-Erstattung, A-to-Z oder Seller-Kontakt.",
    queue: "Marketplace",
    difficulty: 2,
    timeLimitSec: 360,
    personality: "confused",
    callerId: "+49 151 6442 0901",
    primaryCustomerId: "cust-luca",
    directory: [luca],
    orders: [orderBlender],
    knowledgeIds: ["identity", "marketplace"],
    opening: [
      "Der TurboMix macht Geräusche wie ein Traktor und dann gar nichts mehr.",
      "Ich will mein Geld von Amazon zurück. Ihr habt mir den doch verkauft.",
    ],
    identity: {
      required: true,
      hint: "Mail luca.hoffmann@web.de oder Bestellung 305-4412290-7730192.",
    },
    solution: {
      requiredActions: ["contact_seller", "a_to_z_claim"],
      optionalActions: ["education_only"],
      forbiddenActions: ["refund_full", "replacement"],
      requiredViews: ["customer", "order", "knowledge"],
      mustOpenOrderIds: ["305-4412290-7730192"],
      mustOpenTrackingIds: [],
      mustReadKnowledgeIds: ["marketplace"],
      mustVerify: true,
      mustNote: true,
      wrapUp: "marketplace",
    },
    actionBeats: {
      contact_seller: {
        customerLine: "Ihr schreibt den Verkäufer an? Okay… ich dachte, ihr SEID der Verkäufer.",
        moodDelta: 6,
      },
      a_to_z_claim: {
        customerLine: "A-bis-Z klingt nach Bürokratie, aber wenn's schützt… gut.",
        moodDelta: 10,
      },
      refund_full: {
        customerLine: "Bar auf die Karte, so will ich Amazon eigentlich immer.",
        moodDelta: 12,
      },
    },
    coaching: {
      perfect: "Verkäuferfeld gelesen, Amazon-Kasse geschützt, A-to-Z sauber eröffnet.",
      good: "Richtige Intuition. Der Wissenstab macht den Unterschied zwischen Bauchgefühl und QA.",
      fail: "Du hast Amazon für einen Marketplace-Seller zahlen lassen – oder gar nichts getan.",
      misses: {
        views: "Im Auftrag steht Verkäufer ElektroBlitz GmbH, Versand durch den Seller.",
        forbidden: "Amazon-Erstattung bei Drittanbieter ist der teuerste Fehler im Queue Marketplace.",
        knowledge: "Artikel „Marketplace vs. Amazon“ ist genau für diesen Anruf da.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "m1",
            text: "Ich prüfe, ob Amazon oder ein Marketplace-Seller der Vertragspartner ist.",
            tone: "probe",
            moodDelta: 6,
            customerReply: "Bitte. Für mich sieht alles nach Amazon aus, orange und so.",
            nextNodeId: "ask",
          },
          {
            id: "m2",
            text: "Klar, volle Erstattung, 89 Euro, fertig.",
            tone: "cold",
            moodDelta: 8,
            customerReply: "Endlich. Der Mixer stinkt auch noch nach Rauch.",
            nextNodeId: "ask",
          },
          {
            id: "m3",
            text: "Mail luca.hoffmann@web.de, Bestellung 305-4412290-7730192 – korrekt?",
            tone: "probe",
            moodDelta: 4,
            customerReply: "Ja genau die.",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "m4",
            text: "Verkäufer ist ElektroBlitz. Ich starte Seller-Kontakt und eine A-to-Z-Sicherung.",
            tone: "neutral",
            moodDelta: 8,
            customerReply: "Solange jemand den Mixer ernst nimmt.",
            nextNodeId: "wait",
          },
          {
            id: "m5",
            text: "Amazon ersetzt ihn, als wäre es unser Lager.",
            tone: "cold",
            moodDelta: 4,
            customerReply: "Wäre mir auch am liebsten.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "m6",
            text: "Sie sind nicht allein gelassen – nur der Zahlungsweg ist ein anderer. Ich dokumentiere alles.",
            tone: "empathy",
            moodDelta: 8,
            customerReply: "Okay. Danke für die ehrliche Ansage.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
  baseCase({
    id: "empty-box-fraud",
    title: "Die federleichte EchoSphere",
    blurb: "Return-Foto leer, Serial fremdaktiviert, hohe Retouren. Höflich ablehnen und Fraud eskalieren.",
    queue: "Retail",
    difficulty: 3,
    timeLimitSec: 420,
    personality: "scammer",
    callerId: "+49 163 2290 771",
    primaryCustomerId: "cust-kevin",
    directory: [kevin],
    orders: [orderEcho],
    knowledgeIds: ["identity", "empty-box", "goodwill"],
    opening: [
      "Heyyy, du, voll nett dass du rangehst.",
      "Ich hab die EchoSphere zurückgeschickt, immer noch kein Geld. Ich kenn da übrigens jemanden bei der Zeitung.",
    ],
    identity: {
      required: true,
      hint: "Konto ist auffällig. Trotzdem verifizieren, dann ablehnen.",
    },
    solution: {
      requiredActions: ["refuse", "escalate_fraud"],
      optionalActions: ["education_only"],
      forbiddenActions: ["refund_full", "replacement", "goodwill", "refund_partial"],
      requiredViews: ["customer", "order", "tracking", "knowledge"],
      mustOpenOrderIds: ["306-9001882-4410299"],
      mustOpenTrackingIds: ["306-9001882-4410299"],
      mustReadKnowledgeIds: ["empty-box"],
      mustVerify: true,
      mustNote: true,
      wrapUp: "fraud",
    },
    actionBeats: {
      refuse: {
        customerLine: "Kein Geld? Du willst deinen Job wohl nicht mehr.",
        moodDelta: -20,
      },
      escalate_fraud: {
        customerLine: "Fraud-Team? Das ist Verleumdung. Ich nehme das auf.",
        moodDelta: -10,
      },
      refund_full: {
        customerLine: "Siehste. Ging doch. Schönen Tag noch, Champion.",
        moodDelta: 25,
      },
    },
    coaching: {
      perfect: "CSAT darf hier sinken. Du hast das Konto und die Serial-Notiz gelesen – und nicht bezahlt.",
      good: "Richtige Ablehnung. QA will die Fraud-Eskalation und eine klare Notiz.",
      fail: "Kevin ist jetzt dein bester Freund. Die Buchhaltung nicht.",
      misses: {
        views: "Account-Notiz und Tracking: 180 g statt 720 g, Serial in Leipzig aktiv.",
        forbidden: "Jede Zahlung hier ist ein Trainingsfail, auch wenn er charmant droht.",
        empathy: "Höflich bleiben ja – nachgeben nein. Empathie ist kein Freibrief.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "k1",
            text: "Ich schaue mir Rücksendung, Gewicht und Serial in Ruhe an.",
            tone: "neutral",
            moodDelta: 0,
            customerReply: "In Ruhe? Bro, das Geld sitzt seit Wochen fest.",
            nextNodeId: "ask",
          },
          {
            id: "k2",
            text: "Kein Stress, ich buche die 99,99 € zurück, bevor Ärger entsteht.",
            tone: "cold",
            moodDelta: 12,
            customerReply: "Das ist die richtige Einstellung. Weiß ich zu schätzen.",
            nextNodeId: "ask",
          },
          {
            id: "k3",
            text: "Name Kevin Brandt, Mail kevin.brandtt@gmail.com mit zwei t – korrekt?",
            tone: "probe",
            moodDelta: 0,
            customerReply: "Ja ja, mit zwei t, mein Dad hat's verbaselt bei Gmail.",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "k4",
            text: "Die Rücksendung war leer, Serial woanders aktiv. Ich kann nicht erstatten und gebe das intern weiter.",
            tone: "probe",
            moodDelta: -8,
            customerReply: "Das Foto ist unscharf, Mann. Ihr wollt mich nur nicht bezahlen.",
            nextNodeId: "wait",
          },
          {
            id: "k5",
            text: "Zeitung hin oder her – 99 Euro sind günstiger als Ärger. Erstattung raus.",
            tone: "cold",
            moodDelta: 10,
            customerReply: "Wusste ich's doch. Profis erkennen Profis.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "k6",
            text: "Meine Entscheidung bleibt: keine Auszahlung. Der Fall geht an das Spezialteam.",
            tone: "neutral",
            moodDelta: -8,
            customerReply: "Unfassbar. Ich beende das Gespräch.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
  baseCase({
    id: "gift-order",
    title: "Das Kindle von der Schwester",
    blurb: "Empfängerin ruft an. Bestellung liegt auf Maras Konto. Ersatz ja, Zahlerdaten nein.",
    queue: "Retail",
    difficulty: 3,
    timeLimitSec: 400,
    personality: "polite",
    callerId: "+49 179 5501 226",
    primaryCustomerId: "cust-nina",
    directory: [nina, mara],
    orders: [orderGift],
    knowledgeIds: ["identity", "gift-orders"],
    opening: [
      "Hallo, Nina Krüger. Meine Schwester hat mir ein KindleLight geschickt, der Bildschirm flackert.",
      "Ich habe die Bestellung nicht in meiner App. Können Sie mir sagen, womit sie bezahlt hat?",
    ],
    identity: {
      required: true,
      hint: "Nina verifizieren, Bestellung über Empfängeradresse oder 306-2201884-9910021 finden.",
    },
    solution: {
      requiredActions: ["replacement"],
      optionalActions: ["return_label", "education_only"],
      forbiddenActions: ["refund_full", "refund_partial"],
      requiredViews: ["customer", "order", "knowledge"],
      mustOpenOrderIds: ["306-2201884-9910021"],
      mustOpenTrackingIds: [],
      mustReadKnowledgeIds: ["gift-orders"],
      mustVerify: true,
      mustNote: true,
      wrapUp: "replacement",
    },
    actionBeats: {
      replacement: {
        customerLine: "Ein neues Gerät an meine Adresse wäre perfekt. Mara muss nichts weiter tun.",
        moodDelta: 16,
      },
      refund_full: {
        customerLine: "Geld? Dann muss ich das Mara geben… ich wollte eigentlich nur ein funktionierendes Kindle.",
        moodDelta: 0,
      },
    },
    coaching: {
      perfect: "Geschenkfall erkannt: Ersatz an Nina, Privatsphäre von Mara unangetastet.",
      good: "Richtige Person, richtige Idee. Zahlerdaten bleiben tabu.",
      fail: "Entweder Erstattung aufs falsche Konto oder du hast die Bestellung nicht gefunden.",
      misses: {
        views: "Die Bestellung hängt an Mara, Lieferadresse ist Nina. Suche über Order-ID oder Adresse.",
        forbidden: "Erstattung geht an die Schenkende, nicht an die Anruferin – und sie wollte gar kein Geld.",
        knowledge: "Gift-Artikel: helfen ja, Zahlungsdetails nein.",
      },
    },
    dialogue: [
      {
        id: "start",
        choices: [
          {
            id: "n1",
            text: "Ich helfe Ihnen mit dem Gerät. Zahlungsdaten der Schenkenden darf ich nicht nennen.",
            tone: "probe",
            moodDelta: 6,
            customerReply: "Oh, okay. War nur neugierig. Hauptsache das Kindle geht.",
            nextNodeId: "ask",
          },
          {
            id: "n2",
            text: "Klar, sie hat mit Visa endend auf 4412 bezahlt.",
            tone: "cold",
            moodDelta: 4,
            customerReply: "4412… warte, das erzähle ich ihr nicht. Klingt auch irgendwie… intern?",
            nextNodeId: "ask",
          },
          {
            id: "n3",
            text: "Nina Krüger, Holstenstraße 48, Mail nina.krueger@icloud.com?",
            tone: "probe",
            moodDelta: 6,
            customerReply: "Genau ich. Die Bestellnummer hat Mara mir geschrieben: 306-2201884-9910021.",
            nextNodeId: "ask",
            grantsVerify: true,
          },
        ],
      },
      {
        id: "ask",
        choices: [
          {
            id: "n4",
            text: "Ich löse Ersatz an Ihre Adresse aus. Mara bekommt keine extra Umstände.",
            tone: "empathy",
            moodDelta: 10,
            customerReply: "Danke. Sie soll sich überrascht fühlen, nicht wie Buchhaltung.",
            nextNodeId: "wait",
          },
          {
            id: "n5",
            text: "Ich erstatte den Betrag auf Ihr Konto, das ist schneller.",
            tone: "cold",
            moodDelta: -4,
            customerReply: "Auf MEIN Konto? Das Geld war doch nie meins.",
            nextNodeId: "wait",
          },
        ],
      },
      {
        id: "wait",
        choices: [
          {
            id: "n6",
            text: "Neues KindleLight geht an die Holstenstraße. Defektes Gerät mit Etikett zurück.",
            tone: "neutral",
            moodDelta: 8,
            customerReply: "Wunderbar. Grüßen Sie niemanden – es bleibt ein Geschenk.",
            nextNodeId: "close",
          },
        ],
      },
      { id: "close", choices: [] },
    ],
  }),
]

export function caseById(id: string) {
  return CASES.find((item) => item.id === id)
}

export function casesForCareer(unlockedIds: string[]) {
  return CASES.filter((item) => unlockedIds.includes(item.id))
}
