import type { Personality } from "./types"

export function startMood(personality: Personality) {
  switch (personality) {
    case "sweet":
      return 76
    case "polite":
      return 70
    case "chatty":
      return 66
    case "confused":
      return 62
    case "legal":
      return 54
    case "scammer":
      return 60
    case "angry":
      return 36
  }
}

export function moodLabel(mood: number) {
  if (mood >= 80) return "entspannt"
  if (mood >= 60) return "okay"
  if (mood >= 40) return "genervt"
  if (mood >= 20) return "sauer"
  return "legt auf"
}

export function moodColor(mood: number) {
  if (mood >= 70) return "bg-emerald-400"
  if (mood >= 45) return "bg-amber-400"
  return "bg-red-500"
}
