"use client"

import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { WRAP_LABELS } from "@/lib/scoring"
import type { CallRecord } from "@/lib/types"
import { Check, X } from "lucide-react"

type Props = {
  record: CallRecord
  remaining: number
  onNext: () => void
}

export function CallDebrief({ record, remaining, onNext }: Props) {
  const { score } = record
  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-10">
      <div>
        <p className="text-xs tracking-widest text-muted-foreground uppercase">
          Call geschlossen
        </p>
        <h2 className="font-heading mt-1 text-3xl font-semibold">{record.title}</h2>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <ScoreCard
          label="Kundensicht CSAT"
          value={`${score.csat.toFixed(1)} / 5`}
          hint="Was der Kunde fühlt – Betrüger inklusive."
        />
        <ScoreCard
          label="QA-Score"
          value={`${score.overall}`}
          hint={score.qaPassed ? "Bestanden" : "Nacharbeit fällig"}
          warn={!score.qaPassed}
        />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Bar label="Recherche" value={score.investigation} />
        <Bar label="Policy" value={score.policy} />
        <Bar label="Empathie" value={score.empathy} />
        <Bar label="Tempo" value={score.speed} />
      </div>

      <blockquote className="rounded-xl bg-card p-4 text-sm leading-6 ring-1 ring-foreground/10">
        {score.coach}
      </blockquote>

      <ul className="space-y-2">
        {score.bullets.map((bullet, index) => (
          <li key={index} className="flex gap-2 text-sm">
            {bullet.ok ? (
              <Check className="mt-0.5 size-4 shrink-0 text-emerald-500" />
            ) : (
              <X className="mt-0.5 size-4 shrink-0 text-destructive" />
            )}
            <span>{bullet.text}</span>
          </li>
        ))}
      </ul>

      <p className="text-xs text-muted-foreground">
        Wrap-up: {record.wrapUp ? WRAP_LABELS[record.wrapUp] : "fehlt"} · +
        {score.xp} XP
      </p>

      <Button size="lg" onClick={onNext}>
        {remaining > 0 ? `Nächster Call · noch ${remaining}` : "Schicht auswerten"}
      </Button>
    </div>
  )
}

function ScoreCard({
  label,
  value,
  hint,
  warn,
}: {
  label: string
  value: string
  hint: string
  warn?: boolean
}) {
  return (
    <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`text-2xl font-semibold ${warn ? "text-destructive" : ""}`}>
        {value}
      </p>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </div>
  )
}

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs">
        <span>{label}</span>
        <span className="tabular-nums">{value}</span>
      </div>
      <Progress value={value} />
    </div>
  )
}
