"use client"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { WRAP_LABELS } from "@/lib/scoring"
import type { WrapUpCode } from "@/lib/types"

const CODES = Object.keys(WRAP_LABELS) as WrapUpCode[]

type Props = {
  open: boolean
  onOpenChange: (open: boolean) => void
  selected?: WrapUpCode
  onSelect: (code: WrapUpCode) => void
  onConfirm: () => void
}

export function WrapUpDialog({
  open,
  onOpenChange,
  selected,
  onSelect,
  onConfirm,
}: Props) {
  return (
    <Dialog open={open} onOpenChange={(next) => onOpenChange(next)}>
      <DialogContent className="sm:max-w-lg" showCloseButton>
        <DialogHeader>
          <DialogTitle>Wrap-up</DialogTitle>
          <DialogDescription>
            Welcher Dispo-Code beschreibt, was du wirklich getan hast?
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-2">
          {CODES.map((code) => (
            <Button
              key={code}
              variant={selected === code ? "default" : "outline"}
              className="h-auto whitespace-normal px-3 py-2 text-left"
              onClick={() => onSelect(code)}
            >
              {WRAP_LABELS[code]}
            </Button>
          ))}
        </div>
        <DialogFooter>
          <Button disabled={!selected} onClick={onConfirm}>
            Call schließen
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
