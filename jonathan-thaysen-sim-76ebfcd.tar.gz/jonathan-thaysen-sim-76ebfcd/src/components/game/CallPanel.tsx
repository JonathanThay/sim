"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { mmss } from "@/lib/format"
import { moodColor, moodLabel } from "@/lib/mood"
import type { CaseDefinition, ChatMessage, DialogueChoice } from "@/lib/types"
import { Headphones, Pause, PhoneOff } from "lucide-react"
import { useEffect, useRef } from "react"

type Props = {
  caseDef: CaseDefinition
  agentName: string
  elapsedSec: number
  mood: number
  onHold: boolean
  typing: boolean
  messages: ChatMessage[]
  choices: DialogueChoice[]
  onChoice: (choice: DialogueChoice) => void
  onHoldToggle: () => void
  onWrap: () => void
  hungUp: boolean
}

export function CallPanel({
  caseDef,
  agentName,
  elapsedSec,
  mood,
  onHold,
  typing,
  messages,
  choices,
  onChoice,
  onHoldToggle,
  onWrap,
  hungUp,
}: Props) {
  const scroller = useRef<HTMLDivElement>(null)
  useEffect(() => {
    scroller.current?.scrollTo({
      top: scroller.current.scrollHeight,
      behavior: "smooth",
    })
  }, [messages, typing])

  const overtime = elapsedSec > caseDef.timeLimitSec

  return (
    <section className="flex h-full min-h-0 w-full flex-col border-b bg-card md:border-r md:border-b-0">
      <header className="flex items-center justify-between gap-3 border-b px-4 py-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Headphones className="size-4 text-primary" />
            <p className="truncate text-sm font-medium">
              Live · {caseDef.callerId}
            </p>
          </div>
          <p className="text-xs text-muted-foreground">
            {agentName || "Agent"} · {caseDef.queue}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={overtime ? "destructive" : "secondary"} className="font-mono">
            {mmss(elapsedSec)}
          </Badge>
        </div>
      </header>

      <div className="flex items-center gap-3 border-b px-4 py-2">
        <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
          <div
            className={`h-full transition-all ${moodColor(mood)}`}
            style={{ width: `${Math.max(4, mood)}%` }}
          />
        </div>
        <span className="w-20 text-right text-xs text-muted-foreground">
          {moodLabel(mood)}
        </span>
      </div>

      <div ref={scroller} className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4">
        {messages.map((message) => (
          <Bubble key={message.id} message={message} />
        ))}
        {typing ? (
          <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-muted px-3 py-2 text-sm text-muted-foreground">
            spricht …
          </div>
        ) : null}
        {hungUp ? (
          <p className="text-center text-xs font-medium text-destructive">
            Der Kunde hat aufgelegt.
          </p>
        ) : null}
      </div>

      <div className="space-y-2 border-t p-3">
        <div className="flex gap-2">
          <Button
            variant={onHold ? "secondary" : "outline"}
            size="sm"
            className="flex-1"
            onClick={onHoldToggle}
            disabled={hungUp}
          >
            <Pause data-icon="inline-start" />
            {onHold ? "Zurück holen" : "Hold"}
          </Button>
          <Button variant="destructive" size="sm" className="flex-1" onClick={onWrap}>
            <PhoneOff data-icon="inline-start" />
            Wrap-up
          </Button>
        </div>
        <div className="grid gap-2">
          {hungUp ? (
            <p className="text-xs text-muted-foreground">
              Gespräch vorbei. Wrap-up sichern, sonst fehlt die Notiz.
            </p>
          ) : onHold ? (
            <p className="text-xs text-muted-foreground">
              Kunde hört Wartemusik. Mood pausiert kurz – zu lange Hold nervt.
            </p>
          ) : (
            choices.map((choice) => (
              <Button
                key={choice.id}
                variant="outline"
                className="h-auto whitespace-normal px-3 py-2 text-left text-sm"
                onClick={() => onChoice(choice)}
              >
                {choice.text}
              </Button>
            ))
          )}
        </div>
      </div>
    </section>
  )
}

function Bubble({ message }: { message: ChatMessage }) {
  if (message.from === "system") {
    return (
      <p className="text-center text-[11px] tracking-wide text-muted-foreground uppercase">
        {message.text}
      </p>
    )
  }
  const mine = message.from === "agent"
  return (
    <div className={`flex ${mine ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm leading-5 ${
          mine
            ? "rounded-tr-sm bg-primary text-primary-foreground"
            : "rounded-tl-sm bg-muted"
        }`}
      >
        {message.text}
      </div>
    </div>
  )
}
