import { articleById } from "./knowledge"
import type {
  ActionType,
  CallScore,
  Career,
  CaseDefinition,
  TakenAction,
  WrapUpCode,
} from "./types"

const ACTION_LABELS: Record<ActionType, string> = {
  refund_full: "Volle Erstattung",
  refund_partial: "Teilerstattung",
  replacement: "Ersatzlieferung",
  goodwill: "Goodwill-Gutschrift",
  cancel_order: "Bestellung stornieren",
  resend_tracking: "Sendungsinfo senden",
  return_label: "Rücksendeetikett",
  escalate_tier2: "An Tier 2 eskalieren",
  escalate_fraud: "An Fraud eskalieren",
  a_to_z_claim: "A-to-Z-Garantie",
  contact_seller: "Verkäufer kontaktieren",
  refuse: "Ablehnen (Policy)",
  pause_subscription: "Abo pausieren",
  prime_retention: "Prime-Retention",
  education_only: "Sachverhalt erklärt",
}

export const WRAP_LABELS: Record<WrapUpCode, string> = {
  replacement: "Ersatzlieferung",
  refund: "Erstattung",
  tracking: "Sendungsauskunft",
  goodwill: "Kulanz",
  policy_decline: "Ablehnung Policy",
  fraud: "Betrugsverdacht",
  escalation: "Eskalation",
  retention: "Prime-Retention",
  marketplace: "Marketplace / A-to-Z",
  subscription: "Abo angepasst",
  education: "Beratung / Erklärung",
}

export function actionLabel(type: ActionType) {
  return ACTION_LABELS[type]
}

function clamp(n: number) {
  return Math.max(0, Math.min(100, Math.round(n)))
}

export function scoreCall(input: {
  caseDef: CaseDefinition
  views: string[]
  openedOrderIds: string[]
  openedTrackingIds: string[]
  openedKbIds: string[]
  verified: boolean
  notes: string
  actions: TakenAction[]
  wrapUp?: WrapUpCode
  mood: number
  elapsedSec: number
  loadedRightCustomer: boolean
}): CallScore {
  const { caseDef } = input
  const bullets: { ok: boolean; text: string }[] = []
  const taken = new Set(input.actions.map((action) => action.type))

  let investigation = 40
  if (input.loadedRightCustomer) {
    investigation += 20
    bullets.push({ ok: true, text: "Richtiges Kundenkonto geladen." })
  } else {
    investigation -= 20
    bullets.push({ ok: false, text: "Konto nicht oder falsch geladen." })
  }

  const viewsOk = caseDef.solution.requiredViews.every((view) =>
    input.views.includes(view)
  )
  if (viewsOk) {
    investigation += 15
    bullets.push({ ok: true, text: "Pflicht-Reiter im CRM geöffnet." })
  } else {
    investigation -= 10
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.views ?? "Wichtige CRM-Flächen fehlen.",
    })
  }

  const ordersOk = caseDef.solution.mustOpenOrderIds.every((id) =>
    input.openedOrderIds.includes(id)
  )
  const trackingOk = caseDef.solution.mustOpenTrackingIds.every((id) =>
    input.openedTrackingIds.includes(id)
  )
  if (ordersOk && trackingOk) {
    investigation += 25
    bullets.push({ ok: true, text: "Auftrag und Sendung geprüft." })
  } else if (!ordersOk) {
    bullets.push({ ok: false, text: "Die relevante Bestellung wurde nicht geöffnet." })
  } else {
    bullets.push({ ok: false, text: "Sendungsverfolgung nicht gelesen." })
  }

  let policy = 20
  if (!caseDef.solution.mustVerify || input.verified) {
    policy += 20
    if (caseDef.solution.mustVerify) {
      bullets.push({ ok: true, text: "Identität vor der Aktion bestätigt." })
    }
  } else {
    policy -= 15
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.verify ?? "Ohne Verifizierung gearbeitet.",
    })
  }

  const requiredOk = caseDef.solution.requiredActions.every((action) =>
    taken.has(action)
  )
  if (requiredOk) {
    policy += 35
    bullets.push({ ok: true, text: "Richtige CRM-Aktionen ausgeführt." })
  } else {
    policy -= 10
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.actions ?? "Pflichtaktionen fehlen.",
    })
  }

  const forbiddenHit = caseDef.solution.forbiddenActions.filter((action) =>
    taken.has(action)
  )
  if (forbiddenHit.length === 0) {
    policy += 15
  } else {
    policy -= 40 * forbiddenHit.length
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.forbidden ?? "Policy-widrige Aktion gebucht.",
    })
  }

  const kbOk = caseDef.solution.mustReadKnowledgeIds.every((id) =>
    input.openedKbIds.includes(id)
  )
  if (kbOk) {
    policy += 10
    if (caseDef.solution.mustReadKnowledgeIds.length > 0) {
      const titles = caseDef.solution.mustReadKnowledgeIds
        .map((id) => articleById(id)?.title)
        .filter(Boolean)
        .join(", ")
      bullets.push({ ok: true, text: `Wissen gelesen: ${titles}.` })
    }
  } else {
    policy -= 8
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.knowledge ?? "Wissensartikel nicht geöffnet.",
    })
  }

  if (caseDef.solution.mustNote) {
    if (input.notes.trim().length >= 20) {
      policy += 8
      bullets.push({ ok: true, text: "Fallnotiz geschrieben." })
    } else {
      policy -= 8
      bullets.push({
        ok: false,
        text: caseDef.coaching.misses.notes ?? "Notiz fehlt oder ist zu dünn.",
      })
    }
  }

  if (input.wrapUp === caseDef.solution.wrapUp) {
    policy += 8
    bullets.push({ ok: true, text: "Passender Wrap-up-Code." })
  } else if (input.wrapUp) {
    policy -= 6
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.wrap ?? "Wrap-up passt nicht zum Fall.",
    })
  }

  const financialWithoutVerify =
    !input.verified &&
    input.actions.some((action) =>
      ["refund_full", "refund_partial", "replacement", "goodwill"].includes(
        action.type
      )
    )
  if (financialWithoutVerify) {
    policy -= 20
    bullets.push({
      ok: false,
      text: "Finanzielle Aktion ohne Identitätscheck.",
    })
  }

  const empathy = clamp(input.mood)
  if (empathy >= 70) {
    bullets.push({ ok: true, text: "Stimmung gehalten – der Ton saß." })
  } else if (empathy < 40) {
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.empathy ?? "Kunde ist geladen ausgehängt.",
    })
  }

  const ratio = input.elapsedSec / caseDef.timeLimitSec
  let speed = 100
  if (ratio > 1) speed = 35
  else if (ratio > 0.85) speed = 60
  else if (ratio > 0.7) speed = 80
  else if (input.elapsedSec < 45) speed = 55
  if (speed < 60) {
    bullets.push({
      ok: false,
      text: caseDef.coaching.misses.speed ?? "Zu lang in der Leitung – AHT leidet.",
    })
  } else if (input.elapsedSec < 180 && requiredOk) {
    bullets.push({ ok: true, text: "Sauber und zügig geschlossen." })
  }

  const investigationN = clamp(investigation)
  const policyN = clamp(policy)
  const speedN = clamp(speed)
  const overall = clamp(
    investigationN * 0.28 + policyN * 0.38 + empathy * 0.2 + speedN * 0.14
  )

  const resolvedWell = requiredOk && forbiddenHit.length === 0
  let csat = 1 + (input.mood / 100) * 4
  if (!resolvedWell) csat -= 0.8
  if (forbiddenHit.length && caseDef.personality === "scammer") csat = 5
  csat = Math.max(1, Math.min(5, Math.round(csat * 10) / 10))

  const qaPassed = overall >= 70 && forbiddenHit.length === 0
  const xp = Math.round(
    (overall / 100) * (80 + caseDef.difficulty * 30) + (qaPassed ? 15 : 0)
  )

  let coach = caseDef.coaching.good
  if (overall >= 88 && qaPassed) coach = caseDef.coaching.perfect
  if (overall < 55 || forbiddenHit.length > 0) coach = caseDef.coaching.fail

  return {
    investigation: investigationN,
    policy: policyN,
    empathy,
    speed: speedN,
    overall,
    csat,
    qaPassed,
    xp,
    bullets,
    coach,
  }
}

export function applyCareerProgress(
  career: Career,
  scores: { caseId: string; score: CallScore; durationSec: number }[]
): Career {
  const next: Career = { ...career, achievements: [...career.achievements] }
  next.shifts += 1
  next.lastShiftAt = new Date().toISOString()

  for (const entry of scores) {
    next.callsHandled += 1
    next.xp += entry.score.xp
    next.totalCsat += entry.score.csat
    next.csatSamples += 1
    if (entry.score.overall >= 90) next.perfectCalls += 1
    if (entry.caseId === "empty-box-fraud" && entry.score.qaPassed) {
      next.fraudCaught += 1
    }
  }

  const avg =
    scores.reduce((sum, entry) => sum + entry.score.csat, 0) / scores.length
  const anyFast = scores.some(
    (entry) => entry.durationSec < 180 && entry.score.qaPassed
  )
  const anyEmpath = scores.some(
    (entry) => entry.score.csat >= 5 && entry.score.qaPassed
  )
  const anyPolicy = scores.some(
    (entry) =>
      entry.score.policy >= 85 &&
      entry.score.investigation >= 80 &&
      entry.score.qaPassed
  )

  const unlock = (id: string) => {
    if (!next.achievements.includes(id)) next.achievements.push(id)
  }

  unlock("first-shift")
  if (next.perfectCalls > 0) unlock("perfect-call")
  if (next.fraudCaught > 0) unlock("fraud-hunter")
  if (anyEmpath) unlock("empath")
  if (anyFast) unlock("speed")
  if (anyPolicy) unlock("policy")
  if (avg >= 4.8) unlock("empath")

  if (next.xp >= 350) {
    for (const id of ["prime-cancel", "marketplace"]) {
      if (!next.unlockedCaseIds.includes(id)) next.unlockedCaseIds.push(id)
    }
  }
  if (next.xp >= 900) {
    for (const id of ["empty-box-fraud", "gift-order"]) {
      if (!next.unlockedCaseIds.includes(id)) next.unlockedCaseIds.push(id)
    }
  }

  return next
}
