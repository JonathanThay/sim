import { GameApp } from "@/components/game/GameApp"

export default function Home() {
  return (
    <main className="flex min-h-0 flex-1 flex-col">
      <GameApp />
    </main>
  )
}
