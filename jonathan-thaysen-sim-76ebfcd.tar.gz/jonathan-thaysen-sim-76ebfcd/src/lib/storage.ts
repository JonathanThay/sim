import { useSyncExternalStore } from "react"
import { defaultCareer } from "./ranks"
import type { Career } from "./types"

const KEY = "primedesk-career-v1"
const EVENT = "primedesk-career"

function parseCareer(raw: string | null): Career {
  const base = defaultCareer()
  if (!raw) return base
  try {
    const parsed = JSON.parse(raw) as Partial<Career>
    const unlocked =
      Array.isArray(parsed.unlockedCaseIds) && parsed.unlockedCaseIds.length > 0
        ? parsed.unlockedCaseIds
        : base.unlockedCaseIds
    return {
      ...base,
      ...parsed,
      unlockedCaseIds: unlocked,
      achievements: Array.isArray(parsed.achievements)
        ? parsed.achievements
        : base.achievements,
    }
  } catch {
    return base
  }
}

function readRaw() {
  try {
    return window.localStorage.getItem(KEY)
  } catch {
    return null
  }
}

export function loadCareer(): Career {
  if (typeof window === "undefined") return defaultCareer()
  return parseCareer(readRaw())
}

function emit() {
  window.dispatchEvent(new Event(EVENT))
}

export function saveCareer(career: Career) {
  if (typeof window === "undefined") return
  try {
    window.localStorage.setItem(KEY, JSON.stringify(career))
  } catch {
    // Private mode / embedded preview can block storage.
  }
  emit()
}

export function resetCareer() {
  if (typeof window === "undefined") return
  try {
    window.localStorage.removeItem(KEY)
  } catch {
    // ignore
  }
  emit()
}

function subscribe(onStoreChange: () => void) {
  window.addEventListener(EVENT, onStoreChange)
  window.addEventListener("storage", onStoreChange)
  return () => {
    window.removeEventListener(EVENT, onStoreChange)
    window.removeEventListener("storage", onStoreChange)
  }
}

export function useCareer(): Career {
  const json = useSyncExternalStore(
    subscribe,
    () => readRaw(),
    () => null
  )
  return parseCareer(json)
}
